package ma.estm.bibliotheque.util;

import org.junit.Test;

import static org.junit.Assert.*;

public class PasswordUtilTest {

    @Test
    public void testHashPassword() {
        String password = "testpassword123";
        String hashed = PasswordUtil.hashPassword(password);

        assertNotNull("Hash ne doit pas être null", hashed);
        assertNotEquals("Hash doit être différent du mot de passe", password, hashed);
        assertTrue("Hash doit commencer par $2a$ (BCrypt)", hashed.startsWith("$2a$"));
    }

    @Test
    public void testVerifyPassword_Correct() {
        String password = "mypassword";
        String hashed = PasswordUtil.hashPassword(password);

        boolean isValid = PasswordUtil.verifyPassword(password, hashed);

        assertTrue("Le mot de passe doit être valide", isValid);
    }

    @Test
    public void testVerifyPassword_Incorrect() {
        String password = "mypassword";
        String wrongPassword = "wrongpassword";
        String hashed = PasswordUtil.hashPassword(password);

        boolean isValid = PasswordUtil.verifyPassword(wrongPassword, hashed);

        assertFalse("Le mauvais mot de passe doit être invalide", isValid);
    }

    @Test
    public void testHashPassword_SamePasswordDifferentHash() {
        String password = "samepassword";
        String hash1 = PasswordUtil.hashPassword(password);
        String hash2 = PasswordUtil.hashPassword(password);

        assertNotEquals("Deux hashs du même mot de passe doivent être différents (salt)",
                hash1, hash2);

        // Mais les deux doivent être valides
        assertTrue("Hash1 doit être valide", PasswordUtil.verifyPassword(password, hash1));
        assertTrue("Hash2 doit être valide", PasswordUtil.verifyPassword(password, hash2));
    }
}