package ma.estm.bibliotheque.util;

import org.junit.Test;

import java.util.Calendar;
import java.util.Date;

import static org.junit.Assert.*;

public class DateUtilTest {

    @Test
    public void testFormatDate() {
        Calendar cal = Calendar.getInstance();
        cal.set(2024, Calendar.JANUARY, 15); // 15 janvier 2024
        Date date = cal.getTime();

        String formatted = DateUtil.formatDate(date);

        assertTrue("Format doit contenir 15", formatted.contains("15"));
        assertTrue("Format doit contenir 01", formatted.contains("01"));
        assertTrue("Format doit contenir 2024", formatted.contains("2024"));
    }

    @Test
    public void testFormatDate_Null() {
        String formatted = DateUtil.formatDate(null);
        assertEquals("Date null doit retourner chaîne vide", "", formatted);
    }

    @Test
    public void testFormatDateTime() {
        Date date = new Date();
        String formatted = DateUtil.formatDateTime(date);

        assertNotNull("DateTime ne doit pas être null", formatted);
        assertTrue("DateTime doit contenir :", formatted.contains(":"));
    }

    @Test
    public void testToSqlDate() {
        Date date = new Date();
        java.sql.Date sqlDate = DateUtil.toSqlDate(date);

        assertNotNull("SQL Date ne doit pas être null", sqlDate);
    }

    @Test
    public void testToSqlDate_Null() {
        java.sql.Date sqlDate = DateUtil.toSqlDate(null);
        assertNull("SQL Date doit être null si date null", sqlDate);
    }
}