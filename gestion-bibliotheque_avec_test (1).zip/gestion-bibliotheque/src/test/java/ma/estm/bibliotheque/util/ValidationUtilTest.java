package ma.estm.bibliotheque.util;

import org.junit.Test;

import static org.junit.Assert.*;

public class ValidationUtilTest {

    @Test
    public void testIsValidEmail_Valid() {
        assertTrue(ValidationUtil.isValidEmail("test@example.com"));
        assertTrue(ValidationUtil.isValidEmail("user.name@domain.co.uk"));
        assertTrue(ValidationUtil.isValidEmail("user+tag@example.com"));
    }

    @Test
    public void testIsValidEmail_Invalid() {
        assertFalse(ValidationUtil.isValidEmail("invalid"));
        assertFalse(ValidationUtil.isValidEmail("@example.com"));
        assertFalse(ValidationUtil.isValidEmail("user@"));
        assertFalse(ValidationUtil.isValidEmail("user @example.com"));
        assertFalse(ValidationUtil.isValidEmail(null));
    }

   // @Test
   // public void testIsValidISBN_Valid() {
       // assertTrue(ValidationUtil.isValidISBN("9781234567890")); // ISBN-13
       // assertTrue(ValidationUtil.isValidISBN("1234567890")); // ISBN-10
       // assertTrue(ValidationUtil.isValidISBN("978-1-234-56789-0")); // Avec tirets
   // }

   // @Test
   // public void testIsValidISBN_Invalid() {
    //    assertFalse(ValidationUtil.isValidISBN("123")); // Trop court
    //    assertFalse(ValidationUtil.isValidISBN("12345678901234")); // Trop long
   //     assertFalse(ValidationUtil.isValidISBN("abcd1234567890")); // Lettres
   //     assertFalse(ValidationUtil.isValidISBN(null));
   // }

    @Test
    public void testIsNotEmpty_Valid() {
        assertTrue(ValidationUtil.isNotEmpty("test"));
        assertTrue(ValidationUtil.isNotEmpty("  test  ")); // Avec espaces
    }

    @Test
    public void testIsNotEmpty_Invalid() {
        assertFalse(ValidationUtil.isNotEmpty(""));
        assertFalse(ValidationUtil.isNotEmpty("   ")); // Seulement espaces
        assertFalse(ValidationUtil.isNotEmpty(null));
    }

    @Test
    public void testIsPositiveNumber() {
        assertTrue(ValidationUtil.isPositiveNumber(1));
        assertTrue(ValidationUtil.isPositiveNumber(100));
        assertFalse(ValidationUtil.isPositiveNumber(0));
        assertFalse(ValidationUtil.isPositiveNumber(-1));
    }
}