package ma.estm.bibliotheque.service;

import ma.estm.bibliotheque.dao.UtilisateurDAO;
import ma.estm.bibliotheque.dao.impl.UtilisateurDAOImpl;
import ma.estm.bibliotheque.model.Role;
import ma.estm.bibliotheque.model.Utilisateur;
import ma.estm.bibliotheque.dao.DatabaseConnection;
import ma.estm.bibliotheque.util.PasswordUtil;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class AuthenticationServiceTest {

    private AuthenticationService authService;
    private UtilisateurDAO utilisateurDAO;

    @Before
    public void setUp() throws Exception {
        // Initialiser la connexion BD
        DatabaseConnection.getConnection();

        authService = new AuthenticationService();
        utilisateurDAO = new UtilisateurDAOImpl();

        // Créer un utilisateur de test s'il n'existe pas
        Utilisateur testUser = utilisateurDAO.findByLogin("testuser");
        if (testUser == null) {
            testUser = new Utilisateur();
            testUser.setLogin("testuser");
            testUser.setMotDePasseHache(PasswordUtil.hashPassword("testpass"));
            testUser.setRole(Role.USER);
            testUser.setActif(true);
            utilisateurDAO.save(testUser);
        }
    }

    @Test
    public void testAuthenticate_Success() {
        // Test authentification réussie
        Utilisateur user = authService.authenticate("testuser", "testpass");

        assertNotNull("L'utilisateur ne doit pas être null", user);
        assertEquals("Le login doit correspondre", "testuser", user.getLogin());
        assertEquals("Le rôle doit être USER", Role.USER, user.getRole());
    }

    @Test
    public void testAuthenticate_WrongPassword() {
        // Test avec mauvais mot de passe
        Utilisateur user = authService.authenticate("testuser", "wrongpassword");

        assertNull("L'utilisateur doit être null avec mauvais mot de passe", user);
    }

    @Test
    public void testAuthenticate_NonExistentUser() {
        // Test avec utilisateur inexistant
        Utilisateur user = authService.authenticate("nonexistent", "password");

        assertNull("L'utilisateur doit être null s'il n'existe pas", user);
    }

    @Test
    public void testAuthenticate_InactiveUser() {
        // Créer un utilisateur inactif
        Utilisateur inactiveUser = new Utilisateur();
        inactiveUser.setLogin("inactiveuser");
        inactiveUser.setMotDePasseHache(PasswordUtil.hashPassword("pass"));
        inactiveUser.setRole(Role.USER);
        inactiveUser.setActif(false);
        utilisateurDAO.save(inactiveUser);

        try {
            authService.authenticate("inactiveuser", "pass");
            fail("Devrait lever une exception pour compte désactivé");
        } catch (RuntimeException e) {
            assertEquals("Message d'erreur correct", "Compte désactivé", e.getMessage());
        }
    }

    @Test
    public void testIsAdmin() {
        // Créer un admin
        Utilisateur admin = new Utilisateur();
        admin.setLogin("testadmin");
        admin.setMotDePasseHache(PasswordUtil.hashPassword("admin"));
        admin.setRole(Role.ADMIN);
        admin.setActif(true);
        utilisateurDAO.save(admin);

        // S'authentifier en tant qu'admin
        authService.authenticate("testadmin", "admin");

        assertTrue("Doit être identifié comme admin", AuthenticationService.isAdmin());
    }
}