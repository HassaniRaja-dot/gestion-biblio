package ma.estm.bibliotheque.dao;

import ma.estm.bibliotheque.dao.impl.LivreDAOImpl;
import ma.estm.bibliotheque.model.Livre;
import ma.estm.bibliotheque.dao.DatabaseConnection;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class LivreDAOTest {

    private LivreDAO livreDAO;

    @Before
    public void setUp() throws Exception {
        DatabaseConnection.getConnection();
        livreDAO = new LivreDAOImpl();
    }

    @Test
    public void testSave() {
        Livre livre = new Livre();
        String uniqueIsbn = "978" + System.currentTimeMillis();
        livre.setIsbn(uniqueIsbn);
        livre.setTitre("DAO Test Book");
        livre.setAuteur("DAO Author");
        livre.setNombreExemplaires(3);
        livre.setExemplairesDisponibles(3);

        livreDAO.save(livre);

        assertTrue("ID doit être généré", livre.getId() > 0);
    }

    @Test
    public void testFindByIsbn() {
        String isbn = "978" + System.currentTimeMillis();
        Livre livre = new Livre();
        livre.setIsbn(isbn);
        livre.setTitre("ISBN Test");
        livre.setAuteur("Author");
        livre.setNombreExemplaires(5);
        livre.setExemplairesDisponibles(5);
        livreDAO.save(livre);

        Livre found = livreDAO.findByIsbn(isbn);

        assertNotNull("Livre doit être trouvé", found);
        assertEquals("ISBN doit correspondre", isbn, found.getIsbn());
    }

    @Test
    public void testFindAll() {
        List<Livre> livres = livreDAO.findAll();

        assertNotNull("La liste ne doit pas être null", livres);
    }

    @Test
    public void testSearch() {
        // Créer un livre avec un titre unique
        String uniqueTitle = "SearchTest" + System.currentTimeMillis();
        String uniqueIsbn = "978" + System.currentTimeMillis();
        Livre livre = new Livre();
        livre.setIsbn(uniqueIsbn);
        livre.setTitre(uniqueTitle);
        livre.setAuteur("Author");
        livre.setNombreExemplaires(2);
        livre.setExemplairesDisponibles(2);
        livreDAO.save(livre);

        List<Livre> results = livreDAO.search(uniqueTitle);

        assertNotNull("Résultats ne doivent pas être null", results);
        assertTrue("Doit trouver au moins un livre", results.size() > 0);

        // Vérifier que le livre créé est dans les résultats
        boolean found = results.stream()
                .anyMatch(l -> l.getTitre().equals(uniqueTitle));
        assertTrue("Le livre créé doit être dans les résultats", found);
    }

    @Test
    public void testUpdate() {
        String uniqueIsbn = "978" + System.currentTimeMillis();
        Livre livre = new Livre();
        livre.setIsbn(uniqueIsbn);
        livre.setTitre("Original");
        livre.setAuteur("Original Author");
        livre.setNombreExemplaires(5);
        livre.setExemplairesDisponibles(5);
        livreDAO.save(livre);

        livre.setTitre("Updated");
        livre.setExemplairesDisponibles(3);
        livreDAO.update(livre);

        Livre updated = livreDAO.findById(livre.getId());
        assertNotNull("Livre doit exister", updated);
        assertEquals("Titre doit être modifié", "Updated", updated.getTitre());
        assertEquals("Exemplaires disponibles modifiés", 3, updated.getExemplairesDisponibles());
    }
}