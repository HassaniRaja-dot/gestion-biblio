package ma.estm.bibliotheque.service;

import ma.estm.bibliotheque.model.Livre;
import ma.estm.bibliotheque.dao.DatabaseConnection;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class LivreServiceTest {

    private LivreService livreService;

    @Before
    public void setUp() throws Exception {
        DatabaseConnection.getConnection();
        livreService = new LivreService();
    }

    @Test
    public void testAjouterLivre_Success() throws Exception {
        // Créer un livre avec ISBN unique
        String uniqueIsbn = "978" + System.currentTimeMillis();
        Livre livre = new Livre();
        livre.setIsbn(uniqueIsbn);
        livre.setTitre("Test Book");
        livre.setAuteur("Test Author");
        livre.setNombreExemplaires(5);

        // Ajouter le livre
        livreService.ajouterLivre(livre);

        // Vérifications
        assertTrue("ID doit être généré", livre.getId() > 0);
        assertEquals("Exemplaires disponibles doivent être égaux au total",
                livre.getNombreExemplaires(), livre.getExemplairesDisponibles());
    }

    @Test(expected = Exception.class)
    public void testAjouterLivre_ISBNVide() throws Exception {
        Livre livre = new Livre();
        livre.setIsbn("");
        livre.setTitre("Test");
        livre.setAuteur("Author");
        livre.setNombreExemplaires(5);

        livreService.ajouterLivre(livre);
    }

    @Test(expected = Exception.class)
    public void testAjouterLivre_ISBNInvalide() throws Exception {
        Livre livre = new Livre();
        livre.setIsbn("123"); // ISBN invalide
        livre.setTitre("Test");
        livre.setAuteur("Author");
        livre.setNombreExemplaires(5);

        livreService.ajouterLivre(livre);
    }

    @Test(expected = Exception.class)
    public void testAjouterLivre_TitreVide() throws Exception {
        Livre livre = new Livre();
        livre.setIsbn("9781234567891");
        livre.setTitre("");
        livre.setAuteur("Author");
        livre.setNombreExemplaires(5);

        livreService.ajouterLivre(livre);
    }

    @Test(expected = Exception.class)
    public void testAjouterLivre_AuteurVide() throws Exception {
        Livre livre = new Livre();
        livre.setIsbn("9781234567892");
        livre.setTitre("Test");
        livre.setAuteur("");
        livre.setNombreExemplaires(5);

        livreService.ajouterLivre(livre);
    }

    @Test(expected = Exception.class)
    public void testAjouterLivre_ExemplairesZero() throws Exception {
        Livre livre = new Livre();
        livre.setIsbn("9781234567893");
        livre.setTitre("Test");
        livre.setAuteur("Author");
        livre.setNombreExemplaires(0);

        livreService.ajouterLivre(livre);
    }

    @Test
    public void testSearchLivres() {
        // Rechercher des livres
        List<Livre> livres = livreService.searchLivres("Test");

        assertNotNull("La liste ne doit pas être null", livres);
        // Si on a ajouté des livres dans d'autres tests
        // assertTrue("Doit trouver au moins un livre", livres.size() > 0);
    }

    //@Test
   // public void testModifierLivre() throws Exception {
        // Créer et ajouter un livre
      //  Livre livre = new Livre();
    //    livre.setIsbn("9781234567894");
    //    livre.setTitre("Original Title");
     //   livre.setAuteur("Original Author");
     //   livre.setNombreExemplaires(3);
    //    livreService.ajouterLivre(livre);

        // Modifier le livre
      //  livre.setTitre("Modified Title");
      //  livre.setAuteur("Modified Author");
      //  livreService.modifierLivre(livre);

        // Récupérer et vérifier
       // Livre updated = livreService.getLivreById(livre.getId());
       // assertEquals("Titre modifié", "Modified Title", updated.getTitre());
       // assertEquals("Auteur modifié", "Modified Author", updated.getAuteur());
   // }
}