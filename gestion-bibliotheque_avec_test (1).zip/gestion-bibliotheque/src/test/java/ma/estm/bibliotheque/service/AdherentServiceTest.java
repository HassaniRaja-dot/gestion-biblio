package ma.estm.bibliotheque.service;

import ma.estm.bibliotheque.model.Adherent;
import ma.estm.bibliotheque.dao.DatabaseConnection;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class AdherentServiceTest {

    private AdherentService adherentService;

    @Before
    public void setUp() throws Exception {
        DatabaseConnection.getConnection();
        adherentService = new AdherentService();
    }

    @Test
    public void testAjouterAdherent_Success() throws Exception {
        Adherent adherent = new Adherent();
        adherent.setNom("Test");
        adherent.setPrenom("User");
        adherent.setEmail("test" + System.currentTimeMillis() + "@test.com");

        adherentService.ajouterAdherent(adherent);

        assertNotNull("Numéro adhérent doit être généré", adherent.getNumeroAdherent());
        assertTrue("Numéro doit commencer par ADH",
                adherent.getNumeroAdherent().startsWith("ADH"));
        assertTrue("ID doit être généré", adherent.getId() > 0);
    }

    @Test(expected = Exception.class)
    public void testAjouterAdherent_NomVide() throws Exception {
        Adherent adherent = new Adherent();
        adherent.setNom("");
        adherent.setPrenom("Test");
        adherent.setEmail("test@test.com");

        adherentService.ajouterAdherent(adherent);
    }

    @Test(expected = Exception.class)
    public void testAjouterAdherent_EmailInvalide() throws Exception {
        Adherent adherent = new Adherent();
        adherent.setNom("Test");
        adherent.setPrenom("User");
        adherent.setEmail("invalid-email");

        adherentService.ajouterAdherent(adherent);
    }

    @Test
    public void testSearchAdherents() {
        List<Adherent> adherents = adherentService.searchAdherents("Test");

        assertNotNull("La liste ne doit pas être null", adherents);
    }

    @Test
    public void testGetAllAdherents() {
        List<Adherent> adherents = adherentService.getAllAdherents();

        assertNotNull("La liste ne doit pas être null", adherents);
    }
}