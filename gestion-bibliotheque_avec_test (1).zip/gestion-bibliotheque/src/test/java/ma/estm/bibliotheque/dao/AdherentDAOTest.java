package ma.estm.bibliotheque.dao;

import ma.estm.bibliotheque.dao.impl.AdherentDAOImpl;
import ma.estm.bibliotheque.model.Adherent;
import ma.estm.bibliotheque.dao.DatabaseConnection;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class AdherentDAOTest {

    private AdherentDAO adherentDAO;

    @Before
    public void setUp() throws Exception {
        DatabaseConnection.getConnection();
        adherentDAO = new AdherentDAOImpl();
    }

    @Test
    public void testSave() {
        Adherent adherent = new Adherent();
        adherent.setNumeroAdherent("ADHDAO" + System.currentTimeMillis());
        adherent.setNom("DAO");
        adherent.setPrenom("Test");
        adherent.setEmail("dao" + System.currentTimeMillis() + "@test.com");

        adherentDAO.save(adherent);

        assertTrue("ID doit être généré", adherent.getId() > 0);
    }

    @Test
    public void testFindByNumero() {
        String numero = "ADHDAO" + System.currentTimeMillis();
        Adherent adherent = new Adherent();
        adherent.setNumeroAdherent(numero);
        adherent.setNom("Test");
        adherent.setPrenom("Numero");
        adherent.setEmail("numero" + System.currentTimeMillis() + "@test.com");
        adherentDAO.save(adherent);

        Adherent found = adherentDAO.findByNumero(numero);

        assertNotNull("Adhérent doit être trouvé", found);
        assertEquals("Numéro doit correspondre", numero, found.getNumeroAdherent());
    }

   // @Test
   // public void testFindByEmail() {
     //   String email = "unique" + System.currentTimeMillis() + "@test.com";
     //   Adherent adherent = new Adherent();
     //   adherent.setNumeroAdherent("ADHDAO003");
     //   adherent.setNom("Test");
    //    adherent.setPrenom("Email");
     //   adherent.setEmail(email);
     //   adherentDAO.save(adherent);

    //    Adherent found = adherentDAO.findByEmail(email);

    //    assertNotNull("Adhérent doit être trouvé", found);
    //    assertEquals("Email doit correspondre", email, found.getEmail());
  //  }

    @Test
    public void testFindAll() {
        List<Adherent> adherents = adherentDAO.findAll();

        assertNotNull("La liste ne doit pas être null", adherents);
    }

    @Test
    public void testSearch() {
        String uniqueName = "SearchName" + System.currentTimeMillis();
        Adherent adherent = new Adherent();
        adherent.setNumeroAdherent("ADHDAO" + System.currentTimeMillis());
        adherent.setNom(uniqueName);
        adherent.setPrenom("Test");
        adherent.setEmail("search" + System.currentTimeMillis() + "@test.com");
        adherentDAO.save(adherent);

        // Attendre un peu pour être sûr que la sauvegarde est complète
        try { Thread.sleep(100); } catch (InterruptedException e) {}

        List<Adherent> results = adherentDAO.search(uniqueName);

        assertNotNull("Résultats ne doivent pas être null", results);
        assertTrue("Doit trouver au moins un adhérent", results.size() > 0);

        // Vérifier que l'adhérent créé est dans les résultats
        boolean found = results.stream()
                .anyMatch(a -> a.getNom().equals(uniqueName));
        assertTrue("L'adhérent créé doit être dans les résultats", found);
    }
}