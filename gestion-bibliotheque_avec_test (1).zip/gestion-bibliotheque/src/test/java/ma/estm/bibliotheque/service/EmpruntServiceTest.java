package ma.estm.bibliotheque.service;

import ma.estm.bibliotheque.dao.AdherentDAO;
import ma.estm.bibliotheque.dao.LivreDAO;
import ma.estm.bibliotheque.dao.impl.AdherentDAOImpl;
import ma.estm.bibliotheque.dao.impl.LivreDAOImpl;
import ma.estm.bibliotheque.model.Adherent;
import ma.estm.bibliotheque.model.Livre;
import ma.estm.bibliotheque.dao.DatabaseConnection;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class EmpruntServiceTest {

    private EmpruntService empruntService;
    private LivreDAO livreDAO;
    private AdherentDAO adherentDAO;
    private Livre testLivre;
    private Adherent testAdherent;

    @Before
    public void setUp() throws Exception {
        DatabaseConnection.getConnection();
        empruntService = new EmpruntService();
        livreDAO = new LivreDAOImpl();
        adherentDAO = new AdherentDAOImpl();

        // Créer un livre de test
        testLivre = new Livre();
        testLivre.setIsbn("9789999999999");
        testLivre.setTitre("Test Emprunt Book");
        testLivre.setAuteur("Test Author");
        testLivre.setNombreExemplaires(5);
        testLivre.setExemplairesDisponibles(5);
        livreDAO.save(testLivre);

        // Créer un adhérent de test
        testAdherent = new Adherent();
        testAdherent.setNumeroAdherent("ADHTEST" + System.currentTimeMillis());
        testAdherent.setNom("Test");
        testAdherent.setPrenom("Emprunt");
        testAdherent.setEmail("emprunt" + System.currentTimeMillis() + "@test.com");
        testAdherent.setBloque(false);
        adherentDAO.save(testAdherent);
    }

   // @Test
   // public void testEmprunterLivre_Success() throws Exception {
    //    int exemplairesAvant = testLivre.getExemplairesDisponibles();

    //    empruntService.emprunterLivre(testAdherent.getId(), testLivre.getId());

        // Vérifier que les exemplaires ont diminué
      //  Livre updated = livreDAO.findById(testLivre.getId());
      //  assertEquals("Exemplaires doivent diminuer de 1",
     //           exemplairesAvant - 1, updated.getExemplairesDisponibles());
  //  }

    @Test(expected = Exception.class)
    public void testEmprunterLivre_AdherentBloque() throws Exception {
        // Bloquer l'adhérent
        testAdherent.setBloque(true);
        adherentDAO.update(testAdherent);

        empruntService.emprunterLivre(testAdherent.getId(), testLivre.getId());
    }

    @Test(expected = Exception.class)
    public void testEmprunterLivre_LivreNonDisponible() throws Exception {
        // Mettre les exemplaires à 0
        testLivre.setExemplairesDisponibles(0);
        livreDAO.update(testLivre);

        empruntService.emprunterLivre(testAdherent.getId(), testLivre.getId());
    }

    @Test
    public void testGetEmpruntsByAdherent() {
        var emprunts = empruntService.getEmpruntsByAdherent(testAdherent.getId());

        assertNotNull("La liste ne doit pas être null", emprunts);
    }

    @Test
    public void testGetAllEmprunts() {
        var emprunts = empruntService.getAllEmprunts();

        assertNotNull("La liste ne doit pas être null", emprunts);
    }
}