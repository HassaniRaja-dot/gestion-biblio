package ma.estm.bibliotheque.dao;

import ma.estm.bibliotheque.dao.impl.UtilisateurDAOImpl;
import ma.estm.bibliotheque.model.Role;
import ma.estm.bibliotheque.model.Utilisateur;
import ma.estm.bibliotheque.dao.DatabaseConnection;
import ma.estm.bibliotheque.util.PasswordUtil;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class UtilisateurDAOTest {

    private UtilisateurDAO utilisateurDAO;

    @Before
    public void setUp() throws Exception {
        DatabaseConnection.getConnection();
        utilisateurDAO = new UtilisateurDAOImpl();
    }

    @Test
    public void testSave() {
        Utilisateur user = new Utilisateur();
        user.setLogin("daotestuser" + System.currentTimeMillis());
        user.setMotDePasseHache(PasswordUtil.hashPassword("password"));
        user.setRole(Role.USER);
        user.setActif(true);

        utilisateurDAO.save(user);

        assertTrue("ID doit être généré", user.getId() > 0);
    }

    @Test
    public void testFindByLogin() {
        // Créer un utilisateur
        Utilisateur user = new Utilisateur();
        String login = "findtest" + System.currentTimeMillis();
        user.setLogin(login);
        user.setMotDePasseHache(PasswordUtil.hashPassword("pass"));
        user.setRole(Role.USER);
        user.setActif(true);
        utilisateurDAO.save(user);

        // Rechercher
        Utilisateur found = utilisateurDAO.findByLogin(login);

        assertNotNull("Utilisateur doit être trouvé", found);
        assertEquals("Login doit correspondre", login, found.getLogin());
    }

    @Test
    public void testFindById() {
        Utilisateur user = new Utilisateur();
        user.setLogin("idtest" + System.currentTimeMillis());
        user.setMotDePasseHache(PasswordUtil.hashPassword("pass"));
        user.setRole(Role.ADMIN);
        user.setActif(true);
        utilisateurDAO.save(user);

        Utilisateur found = utilisateurDAO.findById(user.getId());

        assertNotNull("Utilisateur doit être trouvé", found);
        assertEquals("ID doit correspondre", user.getId(), found.getId());
        assertEquals("Rôle doit être ADMIN", Role.ADMIN, found.getRole());
    }

    @Test
    public void testFindAll() {
        List<Utilisateur> users = utilisateurDAO.findAll();

        assertNotNull("La liste ne doit pas être null", users);
        assertTrue("Doit contenir au moins l'admin par défaut", users.size() > 0);
    }

    @Test
    public void testUpdate() {
        Utilisateur user = new Utilisateur();
        user.setLogin("updatetest" + System.currentTimeMillis());
        user.setMotDePasseHache(PasswordUtil.hashPassword("pass"));
        user.setRole(Role.USER);
        user.setActif(true);
        utilisateurDAO.save(user);

        // Modifier
        user.setRole(Role.ADMIN);
        user.setActif(false);
        utilisateurDAO.update(user);

        // Vérifier
        Utilisateur updated = utilisateurDAO.findById(user.getId());
        assertEquals("Rôle doit être ADMIN", Role.ADMIN, updated.getRole());
        assertFalse("Doit être inactif", updated.isActif());
    }

    @Test
    public void testDelete() {
        Utilisateur user = new Utilisateur();
        user.setLogin("deletetest" + System.currentTimeMillis());
        user.setMotDePasseHache(PasswordUtil.hashPassword("pass"));
        user.setRole(Role.USER);
        user.setActif(true);
        utilisateurDAO.save(user);

        int id = user.getId();
        utilisateurDAO.delete(id);

        Utilisateur deleted = utilisateurDAO.findById(id);
        assertNull("Utilisateur doit être supprimé", deleted);
    }
}