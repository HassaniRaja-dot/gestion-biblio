package ma.estm.bibliotheque.ui.panels;

import ma.estm.bibliotheque.dao.CategorieDAO;
import ma.estm.bibliotheque.dao.impl.CategorieDAOImpl;
import ma.estm.bibliotheque.model.Categorie;
import ma.estm.bibliotheque.model.Livre;
import ma.estm.bibliotheque.service.LivreService;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class LivreDialog extends JDialog {
    private JTextField isbnField;
    private JTextField titreField;
    private JTextField auteurField;
    private JTextField editeurField;
    private JTextField anneeField;
    private JTextField exemplairesField;
    private JComboBox<Categorie> categorieCombo;

    private LivreService livreService;
    private Livre livre;
    private boolean confirmed = false;

    public LivreDialog(Frame parent, Livre livre, LivreService livreService) {
        super(parent, livre == null ? "Ajouter un livre" : "Modifier un livre", true);
        this.livre = livre;
        this.livreService = livreService;
        initComponents();

        if (livre != null) {
            populateFields();
        }
    }

    private void initComponents() {
        setSize(500, 500);
        setLocationRelativeTo(getParent());
        setResizable(false);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        mainPanel.setBackground(Color.WHITE);

        // Form Panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        // ISBN
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("ISBN *:"), gbc);

        isbnField = new JTextField(20);
        gbc.gridx = 1;
        formPanel.add(isbnField, gbc);

        // Titre
        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("Titre *:"), gbc);

        titreField = new JTextField(20);
        gbc.gridx = 1;
        formPanel.add(titreField, gbc);

        // Auteur
        gbc.gridx = 0;
        gbc.gridy = 2;
        formPanel.add(new JLabel("Auteur *:"), gbc);

        auteurField = new JTextField(20);
        gbc.gridx = 1;
        formPanel.add(auteurField, gbc);

        // Éditeur
        gbc.gridx = 0;
        gbc.gridy = 3;
        formPanel.add(new JLabel("Éditeur:"), gbc);

        editeurField = new JTextField(20);
        gbc.gridx = 1;
        formPanel.add(editeurField, gbc);

        // Année
        gbc.gridx = 0;
        gbc.gridy = 4;
        formPanel.add(new JLabel("Année:"), gbc);

        anneeField = new JTextField(20);
        gbc.gridx = 1;
        formPanel.add(anneeField, gbc);

        // Nombre d'exemplaires
        gbc.gridx = 0;
        gbc.gridy = 5;
        formPanel.add(new JLabel("Nb Exemplaires *:"), gbc);

        exemplairesField = new JTextField(20);
        gbc.gridx = 1;
        formPanel.add(exemplairesField, gbc);

        // Catégorie
        gbc.gridx = 0;
        gbc.gridy = 6;
        formPanel.add(new JLabel("Catégorie:"), gbc);

        categorieCombo = new JComboBox<>();
        categorieCombo.addItem(null); // Option vide
        loadCategories();
        gbc.gridx = 1;
        formPanel.add(categorieCombo, gbc);

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        buttonPanel.setBackground(Color.WHITE);

        JButton saveButton = new JButton("Enregistrer");
        saveButton.setPreferredSize(new Dimension(120, 35));
        saveButton.setBackground(new Color(46, 204, 113));
        saveButton.setForeground(Color.WHITE);
        saveButton.setFont(new Font("Arial", Font.BOLD, 12));
        saveButton.addActionListener(e -> save());

        JButton cancelButton = new JButton("Annuler");
        cancelButton.setPreferredSize(new Dimension(120, 35));
        cancelButton.setBackground(new Color(149, 165, 166));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFont(new Font("Arial", Font.BOLD, 12));
        cancelButton.addActionListener(e -> dispose());

        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);

        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private void loadCategories() {
        try {
            CategorieDAO categorieDAO = new CategorieDAOImpl();
            List<Categorie> categories = categorieDAO.findAll();
            for (Categorie cat : categories) {
                categorieCombo.addItem(cat);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void populateFields() {
        isbnField.setText(livre.getIsbn());
        isbnField.setEnabled(false); // ISBN non modifiable
        titreField.setText(livre.getTitre());
        auteurField.setText(livre.getAuteur());
        editeurField.setText(livre.getEditeur());
        anneeField.setText(String.valueOf(livre.getAnneePublication()));
        exemplairesField.setText(String.valueOf(livre.getNombreExemplaires()));

        // Sélectionner la catégorie
        if (livre.getCategorieId() > 0) {
            for (int i = 0; i < categorieCombo.getItemCount(); i++) {
                Categorie cat = categorieCombo.getItemAt(i);
                if (cat != null && cat.getId() == livre.getCategorieId()) {
                    categorieCombo.setSelectedIndex(i);
                    break;
                }
            }
        }
    }

    private void save() {
        try {
            // Validation
            String isbn = isbnField.getText().trim();
            String titre = titreField.getText().trim();
            String auteur = auteurField.getText().trim();
            String editeur = editeurField.getText().trim();
            String anneeStr = anneeField.getText().trim();
            String exemplairesStr = exemplairesField.getText().trim();

            if (livre == null) {
                // Nouveau livre
                livre = new Livre();
                livre.setIsbn(isbn);
            }

            livre.setTitre(titre);
            livre.setAuteur(auteur);
            livre.setEditeur(editeur);

            if (!anneeStr.isEmpty()) {
                livre.setAnneePublication(Integer.parseInt(anneeStr));
            }

            livre.setNombreExemplaires(Integer.parseInt(exemplairesStr));

            Categorie selectedCat = (Categorie) categorieCombo.getSelectedItem();
            if (selectedCat != null) {
                livre.setCategorieId(selectedCat.getId());
            }

            // Sauvegarder
            if (livre.getId() == 0) {
                livreService.ajouterLivre(livre);
                JOptionPane.showMessageDialog(this,
                        "Livre ajouté avec succès",
                        "Succès", JOptionPane.INFORMATION_MESSAGE);
            } else {
                livreService.modifierLivre(livre);
                JOptionPane.showMessageDialog(this,
                        "Livre modifié avec succès",
                        "Succès", JOptionPane.INFORMATION_MESSAGE);
            }

            confirmed = true;
            dispose();

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this,
                    "Veuillez saisir des valeurs numériques valides",
                    "Erreur", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erreur: " + e.getMessage(),
                    "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean isConfirmed() {
        return confirmed;
    }
}
