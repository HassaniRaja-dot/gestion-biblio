package ma.estm.bibliotheque.ui.panels;

import ma.estm.bibliotheque.service.AuthenticationService;
import javax.swing.*;
import java.awt.*;

public class DashboardPanel extends JPanel {
    public DashboardPanel() {
        setLayout(new BorderLayout());

        String role = AuthenticationService.isAdmin() ? "Administrateur" : "Utilisateur";
        String user = AuthenticationService.getCurrentUser().getLogin();

        JLabel label = new JLabel(
                "<html><center>" +
                        "<h1>Bibliothèque Universitaire ESTM</h1>" +
                        "<p>Bienvenue " + user + " (" + role + ")</p>" +
                        "</center></html>",
                SwingConstants.CENTER
        );

        add(label, BorderLayout.CENTER);
    }
}