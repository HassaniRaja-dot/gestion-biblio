package ma.estm.bibliotheque.dao;

import ma.estm.bibliotheque.model.Adherent;
import java.util.List;

public interface AdherentDAO {
    Adherent findById(int id);
    Adherent findByNumero(String numeroAdherent);
    Adherent findByEmail(String email);
    List<Adherent> findAll();
    List<Adherent> search(String keyword);
    void save(Adherent adherent);
    void update(Adherent adherent);
    void delete(int id);
    int countEmpruntsActifs(int adherentId);
}
