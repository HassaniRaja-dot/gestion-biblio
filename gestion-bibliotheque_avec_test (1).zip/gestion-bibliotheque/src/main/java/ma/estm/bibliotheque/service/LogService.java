package ma.estm.bibliotheque.service;

import ma.estm.bibliotheque.dao.LogOperationDAO;
import ma.estm.bibliotheque.dao.impl.LogOperationDAOImpl;
import ma.estm.bibliotheque.model.LogOperation;

public class LogService {
    private LogOperationDAO logDAO;

    public LogService() {
        this.logDAO = new LogOperationDAOImpl();
    }

    public void log(String type, String description) {
        try {
            int userId = AuthenticationService.getCurrentUser() != null ?
                    AuthenticationService.getCurrentUser().getId() : 0;

            LogOperation log = new LogOperation(type, description, userId);
            logDAO.save(log);
        } catch (Exception e) {
            // Ne pas faire échouer l'opération principale si le log échoue
            System.err.println("Erreur lors du logging: " + e.getMessage());
        }
    }
}