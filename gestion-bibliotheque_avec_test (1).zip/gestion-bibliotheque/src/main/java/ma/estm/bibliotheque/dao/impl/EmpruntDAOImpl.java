package ma.estm.bibliotheque.dao.impl;



import ma.estm.bibliotheque.dao.EmpruntDAO;
import ma.estm.bibliotheque.model.Emprunt;
import ma.estm.bibliotheque.model.StatutEmprunt;
import ma.estm.bibliotheque.dao.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmpruntDAOImpl implements EmpruntDAO {

    @Override
    public Emprunt findById(int id) {
        String sql = "SELECT e.*, " +
                "CONCAT(a.prenom, ' ', a.nom) as adherent_nom, " +
                "l.titre as livre_titre " +
                "FROM emprunt e " +
                "JOIN adherent a ON e.adherent_id = a.id " +
                "JOIN livre l ON e.livre_id = l.id " +
                "WHERE e.id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return mapResultSetToEmprunt(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Emprunt> findAll() {
        List<Emprunt> emprunts = new ArrayList<>();
        String sql = "SELECT e.*, " +
                "CONCAT(a.prenom, ' ', a.nom) as adherent_nom, " +
                "l.titre as livre_titre " +
                "FROM emprunt e " +
                "JOIN adherent a ON e.adherent_id = a.id " +
                "JOIN livre l ON e.livre_id = l.id " +
                "ORDER BY e.date_emprunt DESC";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                emprunts.add(mapResultSetToEmprunt(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return emprunts;
    }

    @Override
    public List<Emprunt> findByAdherent(int adherentId) {
        List<Emprunt> emprunts = new ArrayList<>();
        String sql = "SELECT e.*, " +
                "CONCAT(a.prenom, ' ', a.nom) as adherent_nom, " +
                "l.titre as livre_titre " +
                "FROM emprunt e " +
                "JOIN adherent a ON e.adherent_id = a.id " +
                "JOIN livre l ON e.livre_id = l.id " +
                "WHERE e.adherent_id = ? " +
                "ORDER BY e.date_emprunt DESC";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, adherentId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                emprunts.add(mapResultSetToEmprunt(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return emprunts;
    }

    @Override
    public List<Emprunt> findByStatut(StatutEmprunt statut) {
        List<Emprunt> emprunts = new ArrayList<>();
        String sql = "SELECT e.*, " +
                "CONCAT(a.prenom, ' ', a.nom) as adherent_nom, " +
                "l.titre as livre_titre " +
                "FROM emprunt e " +
                "JOIN adherent a ON e.adherent_id = a.id " +
                "JOIN livre l ON e.livre_id = l.id " +
                "WHERE e.statut = ? " +
                "ORDER BY e.date_emprunt DESC";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, statut.name());
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                emprunts.add(mapResultSetToEmprunt(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return emprunts;
    }

    @Override
    public List<Emprunt> findEmpruntsEnRetard() {
        List<Emprunt> emprunts = new ArrayList<>();
        String sql = "SELECT e.*, " +
                "CONCAT(a.prenom, ' ', a.nom) as adherent_nom, " +
                "l.titre as livre_titre " +
                "FROM emprunt e " +
                "JOIN adherent a ON e.adherent_id = a.id " +
                "JOIN livre l ON e.livre_id = l.id " +
                "WHERE e.statut = 'EN_COURS' AND e.date_retour_prevue < CURRENT_DATE " +
                "ORDER BY e.date_retour_prevue";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                emprunts.add(mapResultSetToEmprunt(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return emprunts;
    }

    @Override
    public void save(Emprunt emprunt) {
        String sql = "INSERT INTO emprunt (adherent_id, livre_id, date_emprunt, " +
                "date_retour_prevue, date_retour_effective, statut) " +
                "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setInt(1, emprunt.getAdherentId());
            stmt.setInt(2, emprunt.getLivreId());
            stmt.setDate(3, new java.sql.Date(emprunt.getDateEmprunt().getTime()));
            stmt.setDate(4, new java.sql.Date(emprunt.getDateRetourPrevue().getTime()));

            if (emprunt.getDateRetourEffective() != null) {
                stmt.setDate(5, new java.sql.Date(emprunt.getDateRetourEffective().getTime()));
            } else {
                stmt.setNull(5, Types.DATE);
            }

            stmt.setString(6, emprunt.getStatut().name());

            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                emprunt.setId(rs.getInt(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(Emprunt emprunt) {
        String sql = "UPDATE emprunt SET date_retour_effective = ?, statut = ? WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            if (emprunt.getDateRetourEffective() != null) {
                stmt.setDate(1, new java.sql.Date(emprunt.getDateRetourEffective().getTime()));
            } else {
                stmt.setNull(1, Types.DATE);
            }

            stmt.setString(2, emprunt.getStatut().name());
            stmt.setInt(3, emprunt.getId());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(int id) {
        String sql = "DELETE FROM emprunt WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private Emprunt mapResultSetToEmprunt(ResultSet rs) throws SQLException {
        Emprunt emprunt = new Emprunt();
        emprunt.setId(rs.getInt("id"));
        emprunt.setAdherentId(rs.getInt("adherent_id"));
        emprunt.setLivreId(rs.getInt("livre_id"));
        emprunt.setDateEmprunt(rs.getDate("date_emprunt"));
        emprunt.setDateRetourPrevue(rs.getDate("date_retour_prevue"));

        Date dateRetour = rs.getDate("date_retour_effective");
        if (!rs.wasNull()) {
            emprunt.setDateRetourEffective(dateRetour);
        }

        emprunt.setStatut(StatutEmprunt.valueOf(rs.getString("statut")));
        emprunt.setAdherentNom(rs.getString("adherent_nom"));
        emprunt.setLivreTitre(rs.getString("livre_titre"));

        return emprunt;
    }
}
