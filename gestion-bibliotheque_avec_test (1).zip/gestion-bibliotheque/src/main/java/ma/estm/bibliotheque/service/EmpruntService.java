package ma.estm.bibliotheque.service;

import ma.estm.bibliotheque.dao.*;
import ma.estm.bibliotheque.dao.impl.*;
import ma.estm.bibliotheque.model.*;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class EmpruntService {
    private EmpruntDAO empruntDAO;
    private LivreDAO livreDAO;
    private AdherentDAO adherentDAO;
    private LogService logService;

    public EmpruntService() {
        this.empruntDAO = new EmpruntDAOImpl();
        this.livreDAO = new LivreDAOImpl();
        this.adherentDAO = new AdherentDAOImpl();
        this.logService = new LogService();
    }

    public List<Emprunt> getAllEmprunts() {
        return empruntDAO.findAll();
    }

    public List<Emprunt> getEmpruntsByAdherent(int adherentId) {
        return empruntDAO.findByAdherent(adherentId);
    }

    public List<Emprunt> getEmpruntsEnRetard() {
        return empruntDAO.findEmpruntsEnRetard();
    }

    public void emprunterLivre(int adherentId, int livreId) throws Exception {
        // Vérifier adhérent
        Adherent adherent = adherentDAO.findById(adherentId);
        if (adherent == null) {
            throw new Exception("Adhérent introuvable");
        }
        if (adherent.isBloque()) {
            throw new Exception("Adhérent bloqué (retard > 10 jours)");
        }

        // Vérifier limite de 3 emprunts
        int nbEmprunts = adherentDAO.countEmpruntsActifs(adherentId);
        if (nbEmprunts >= 3) {
            throw new Exception("Limite de 3 emprunts simultanés atteinte");
        }

        // Vérifier livre
        Livre livre = livreDAO.findById(livreId);
        if (livre == null) {
            throw new Exception("Livre introuvable");
        }
        if (!livre.estDisponible()) {
            throw new Exception("Aucun exemplaire disponible");
        }

        // Créer l'emprunt
        Emprunt emprunt = new Emprunt(adherentId, livreId);
        empruntDAO.save(emprunt);

        // Décrémenter exemplaires disponibles
        livre.decrementerExemplaires();
        livreDAO.update(livre);

        logService.log("EMPRUNT",
                "Emprunt: " + adherent.getNomComplet() + " - " + livre.getTitre());
    }

    public void retournerLivre(int empruntId) throws Exception {
        Emprunt emprunt = empruntDAO.findById(empruntId);
        if (emprunt == null) {
            throw new Exception("Emprunt introuvable");
        }
        if (emprunt.getStatut() != StatutEmprunt.EN_COURS) {
            throw new Exception("Emprunt déjà clôturé");
        }

        // Clôturer l'emprunt
        emprunt.cloturer();
        empruntDAO.update(emprunt);

        // Incrémenter exemplaires disponibles
        Livre livre = livreDAO.findById(emprunt.getLivreId());
        if (livre != null) {
            livre.incrementerExemplaires();
            livreDAO.update(livre);
        }

        // Vérifier si adhérent doit être bloqué
        if (emprunt.joursRetard() > 10) {
            Adherent adherent = adherentDAO.findById(emprunt.getAdherentId());
            if (adherent != null) {
                adherent.setBloque(true);
                adherentDAO.update(adherent);
            }
        }

        String statut = emprunt.getStatut() == StatutEmprunt.EN_RETARD ?
                " (RETARD: " + emprunt.joursRetard() + " jours)" : "";
        logService.log("RETOUR", "Retour: " + emprunt.getLivreTitre() + statut);
    }

    public void verifierEtBloquerRetards() {
        List<Emprunt> empruntsEnRetard = getEmpruntsEnRetard();

        for (Emprunt emprunt : empruntsEnRetard) {
            if (emprunt.joursRetard() > 10) {
                Adherent adherent = adherentDAO.findById(emprunt.getAdherentId());
                if (adherent != null && !adherent.isBloque()) {
                    adherent.setBloque(true);
                    adherentDAO.update(adherent);
                    System.out.println("Adhérent bloqué: " + adherent.getNomComplet());
                }
            }
        }
    }
}