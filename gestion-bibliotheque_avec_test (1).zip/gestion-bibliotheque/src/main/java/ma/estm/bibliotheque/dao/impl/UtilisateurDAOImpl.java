package ma.estm.bibliotheque.dao.impl;

import ma.estm.bibliotheque.dao.UtilisateurDAO;
import ma.estm.bibliotheque.model.Role;
import ma.estm.bibliotheque.model.Utilisateur;
import ma.estm.bibliotheque.dao.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UtilisateurDAOImpl implements UtilisateurDAO {

    @Override
    public Utilisateur findByLogin(String login) {
        String sql = "SELECT * FROM utilisateur WHERE login = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, login);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return mapResultSetToUtilisateur(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public Utilisateur findById(int id) {
        String sql = "SELECT * FROM utilisateur WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return mapResultSetToUtilisateur(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Utilisateur> findAll() {
        List<Utilisateur> utilisateurs = new ArrayList<>();
        String sql = "SELECT * FROM utilisateur ORDER BY login";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                utilisateurs.add(mapResultSetToUtilisateur(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return utilisateurs;
    }

    @Override
    public void save(Utilisateur utilisateur) {
        String sql = "INSERT INTO utilisateur (login, mot_de_passe_hache, role, actif, adherent_id) " +
                "VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, utilisateur.getLogin());
            stmt.setString(2, utilisateur.getMotDePasseHache());
            stmt.setString(3, utilisateur.getRole().name());
            stmt.setBoolean(4, utilisateur.isActif());

            if (utilisateur.getAdherentId() != null) {
                stmt.setInt(5, utilisateur.getAdherentId());
            } else {
                stmt.setNull(5, Types.INTEGER);
            }

            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                utilisateur.setId(rs.getInt(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(Utilisateur utilisateur) {
        String sql = "UPDATE utilisateur SET login = ?, mot_de_passe_hache = ?, " +
                "role = ?, actif = ?, adherent_id = ? WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, utilisateur.getLogin());
            stmt.setString(2, utilisateur.getMotDePasseHache());
            stmt.setString(3, utilisateur.getRole().name());
            stmt.setBoolean(4, utilisateur.isActif());

            if (utilisateur.getAdherentId() != null) {
                stmt.setInt(5, utilisateur.getAdherentId());
            } else {
                stmt.setNull(5, Types.INTEGER);
            }

            stmt.setInt(6, utilisateur.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(int id) {
        String sql = "DELETE FROM utilisateur WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private Utilisateur mapResultSetToUtilisateur(ResultSet rs) throws SQLException {
        Utilisateur utilisateur = new Utilisateur();
        utilisateur.setId(rs.getInt("id"));
        utilisateur.setLogin(rs.getString("login"));
        utilisateur.setMotDePasseHache(rs.getString("mot_de_passe_hache"));
        utilisateur.setRole(Role.valueOf(rs.getString("role")));
        utilisateur.setActif(rs.getBoolean("actif"));

        int adherentId = rs.getInt("adherent_id");
        if (!rs.wasNull()) {
            utilisateur.setAdherentId(adherentId);
        }

        return utilisateur;
    }
}
