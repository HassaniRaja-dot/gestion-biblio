package ma.estm.bibliotheque.dao;

import ma.estm.bibliotheque.model.Utilisateur;
import java.util.List;

public interface UtilisateurDAO {
    Utilisateur findByLogin(String login);
    Utilisateur findById(int id);
    List<Utilisateur> findAll();
    void save(Utilisateur utilisateur);
    void update(Utilisateur utilisateur);
    void delete(int id);
}
