package ma.estm.bibliotheque.ui.panels;

import ma.estm.bibliotheque.model.Livre;
import ma.estm.bibliotheque.service.AuthenticationService;
import ma.estm.bibliotheque.service.EmpruntService;
import ma.estm.bibliotheque.service.LivreService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class FaireEmpruntPanel extends JPanel {
    private LivreService livreService;
    private EmpruntService empruntService;
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private JLabel infoLabel;

    public FaireEmpruntPanel() {
        livreService = new LivreService();
        empruntService = new EmpruntService();
        initComponents();
        loadLivresDisponibles();
        updateInfo();
    }

    private void initComponents() {
        setLayout(new BorderLayout(5, 5));

        // Top - Info + Recherche
        JPanel topPanel = new JPanel(new BorderLayout());

        infoLabel = new JLabel("Livres disponibles à emprunter", JLabel.CENTER);
        topPanel.add(infoLabel, BorderLayout.NORTH);

        JPanel searchPanel = new JPanel();
        searchPanel.add(new JLabel("Recherche:"));
        searchField = new JTextField(25);
        searchPanel.add(searchField);

        JButton searchBtn = new JButton("Chercher");
        searchBtn.addActionListener(e -> searchLivres());
        searchPanel.add(searchBtn);

        JButton refreshBtn = new JButton("Actualiser");
        refreshBtn.addActionListener(e -> {
            loadLivresDisponibles();
            updateInfo();
        });
        searchPanel.add(refreshBtn);

        topPanel.add(searchPanel, BorderLayout.CENTER);
        add(topPanel, BorderLayout.NORTH);

        // Center - Table des livres disponibles
        String[] columns = {"ID", "ISBN", "Titre", "Auteur", "Éditeur", "Disponibles"};
        tableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Cacher la colonne ID
        table.getColumnModel().getColumn(0).setMinWidth(0);
        table.getColumnModel().getColumn(0).setMaxWidth(0);
        table.getColumnModel().getColumn(0).setWidth(0);

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Bottom - Bouton Emprunter
        JPanel btnPanel = new JPanel();

        JButton empruntBtn = new JButton("Emprunter ce Livre");
        empruntBtn.addActionListener(e -> emprunterLivre());
        btnPanel.add(empruntBtn);

        JButton mesEmpruntsBtn = new JButton("Voir Mes Emprunts");
        mesEmpruntsBtn.addActionListener(e -> showMesEmprunts());
        btnPanel.add(mesEmpruntsBtn);

        add(btnPanel, BorderLayout.SOUTH);
    }

    private void loadLivresDisponibles() {
        tableModel.setRowCount(0);

        var livres = livreService.getAllLivres();
        int nbDisponibles = 0;

        for (Livre livre : livres) {
            if (livre.estDisponible()) {
                tableModel.addRow(new Object[]{
                        livre.getId(),
                        livre.getIsbn(),
                        livre.getTitre(),
                        livre.getAuteur(),
                        livre.getEditeur(),
                        livre.getExemplairesDisponibles()
                });
                nbDisponibles++;
            }
        }

        if (nbDisponibles == 0) {
            JOptionPane.showMessageDialog(this,
                    "Aucun livre disponible actuellement",
                    "Information", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void searchLivres() {
        String keyword = searchField.getText().trim();
        tableModel.setRowCount(0);

        var livres = livreService.searchLivres(keyword);

        for (Livre livre : livres) {
            if (livre.estDisponible()) {
                tableModel.addRow(new Object[]{
                        livre.getId(),
                        livre.getIsbn(),
                        livre.getTitre(),
                        livre.getAuteur(),
                        livre.getEditeur(),
                        livre.getExemplairesDisponibles()
                });
            }
        }
    }

    private void updateInfo() {
        try {
            Integer adherentId = AuthenticationService.getCurrentUser().getAdherentId();

            if (adherentId == null) {
                infoLabel.setText("⚠️ Aucun adhérent lié à ce compte");
                return;
            }

            var emprunts = empruntService.getEmpruntsByAdherent(adherentId);
            int nbEnCours = (int) emprunts.stream()
                    .filter(e -> e.getStatut().toString().equals("EN_COURS"))
                    .count();

            int nbRetard = (int) emprunts.stream()
                    .filter(e -> e.getStatut().toString().equals("EN_COURS") && e.joursRetard() > 0)
                    .count();

            int disponibles = 3 - nbEnCours;

            String message = String.format(
                    "📚 Emprunts : %d/3 en cours | Disponibles : %d | En retard : %d",
                    nbEnCours, disponibles, nbRetard
            );

            infoLabel.setText(message);

            if (nbRetard > 0) {
                infoLabel.setForeground(Color.RED);
            } else if (disponibles == 0) {
                infoLabel.setForeground(Color.ORANGE);
            } else {
                infoLabel.setForeground(Color.BLACK);
            }

        } catch (Exception e) {
            infoLabel.setText("Erreur lors du chargement des infos");
        }
    }

    private void emprunterLivre() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this,
                    "Veuillez sélectionner un livre à emprunter",
                    "Information", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        Integer adherentId = AuthenticationService.getCurrentUser().getAdherentId();

        if (adherentId == null) {
            JOptionPane.showMessageDialog(this,
                    "Votre compte n'est pas lié à un adhérent.\nContactez un administrateur.",
                    "Erreur", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int livreId = (int) tableModel.getValueAt(row, 0);
        String titreLivre = (String) tableModel.getValueAt(row, 2);

        // Confirmation
        int choice = JOptionPane.showConfirmDialog(this,
                "Emprunter le livre :\n\"" + titreLivre + "\" ?\n\nDurée : 14 jours",
                "Confirmation d'emprunt",
                JOptionPane.YES_NO_OPTION);

        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            empruntService.emprunterLivre(adherentId, livreId);

            JOptionPane.showMessageDialog(this,
                    "✅ Emprunt réalisé avec succès!\n\n" +
                            "Livre : " + titreLivre + "\n" +
                            "Durée : 14 jours\n" +
                            "Pensez à le retourner à temps!",
                    "Succès",
                    JOptionPane.INFORMATION_MESSAGE);

            loadLivresDisponibles();
            updateInfo();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "❌ Erreur lors de l'emprunt :\n" + e.getMessage(),
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showMesEmprunts() {
        // Basculer vers le panel Mes Emprunts
        Container parent = getParent();
        if (parent instanceof JPanel) {
            CardLayout layout = (CardLayout) parent.getLayout();
            layout.show(parent, "MES_EMPRUNTS");
        }
    }
}