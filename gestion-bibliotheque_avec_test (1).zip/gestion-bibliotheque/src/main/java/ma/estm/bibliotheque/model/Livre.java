package ma.estm.bibliotheque.model;

public class Livre {
    private int id;
    private String isbn;
    private String titre;
    private String auteur;
    private String editeur;
    private int anneePublication;
    private int nombreExemplaires;
    private int exemplairesDisponibles;
    private int categorieId;
    private String categorieNom;

    public Livre() {}

    public Livre(String isbn, String titre, String auteur, int nombreExemplaires) {
        this.isbn = isbn;
        this.titre = titre;
        this.auteur = auteur;
        this.nombreExemplaires = nombreExemplaires;
        this.exemplairesDisponibles = nombreExemplaires;
    }

    public boolean estDisponible() {
        return exemplairesDisponibles > 0;
    }

    public void incrementerExemplaires() {
        if (exemplairesDisponibles < nombreExemplaires) {
            exemplairesDisponibles++;
        }
    }

    public void decrementerExemplaires() {
        if (exemplairesDisponibles > 0) {
            exemplairesDisponibles--;
        }
    }

    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }

    public String getTitre() { return titre; }
    public void setTitre(String titre) { this.titre = titre; }

    public String getAuteur() { return auteur; }
    public void setAuteur(String auteur) { this.auteur = auteur; }

    public String getEditeur() { return editeur; }
    public void setEditeur(String editeur) { this.editeur = editeur; }

    public int getAnneePublication() { return anneePublication; }
    public void setAnneePublication(int anneePublication) {
        this.anneePublication = anneePublication;
    }

    public int getNombreExemplaires() { return nombreExemplaires; }
    public void setNombreExemplaires(int nombreExemplaires) {
        this.nombreExemplaires = nombreExemplaires;
    }

    public int getExemplairesDisponibles() { return exemplairesDisponibles; }
    public void setExemplairesDisponibles(int exemplairesDisponibles) {
        this.exemplairesDisponibles = exemplairesDisponibles;
    }

    public int getCategorieId() { return categorieId; }
    public void setCategorieId(int categorieId) { this.categorieId = categorieId; }

    public String getCategorieNom() { return categorieNom; }
    public void setCategorieNom(String categorieNom) { this.categorieNom = categorieNom; }
}
