package ma.estm.bibliotheque.ui.panels;

import ma.estm.bibliotheque.dao.AdherentDAO;
import ma.estm.bibliotheque.dao.LivreDAO;
import ma.estm.bibliotheque.dao.impl.AdherentDAOImpl;
import ma.estm.bibliotheque.dao.impl.LivreDAOImpl;
import ma.estm.bibliotheque.model.Adherent;
import ma.estm.bibliotheque.model.Livre;
import ma.estm.bibliotheque.service.EmpruntService;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class EmpruntDialog extends JDialog {
    private JComboBox<AdherentItem> adherentCombo;
    private JComboBox<LivreItem> livreCombo;
    private JTextField searchAdherentField;
    private JTextField searchLivreField;

    private EmpruntService empruntService;
    private AdherentDAO adherentDAO;
    private LivreDAO livreDAO;
    private boolean confirmed = false;

    public EmpruntDialog(Frame parent, EmpruntService empruntService) {
        super(parent, "Nouvel Emprunt", true);
        this.empruntService = empruntService;
        this.adherentDAO = new AdherentDAOImpl();
        this.livreDAO = new LivreDAOImpl();
        initComponents();
    }

    private void initComponents() {
        setSize(550, 350);
        setLocationRelativeTo(getParent());
        setResizable(false);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        mainPanel.setBackground(Color.WHITE);

        // Form Panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        // Adhérent
        gbc.gridx = 0;
        gbc.gridy = 0;
        formPanel.add(new JLabel("Adhérent *:"), gbc);

        JPanel adherentPanel = new JPanel(new BorderLayout(5, 0));
        adherentPanel.setBackground(Color.WHITE);

        searchAdherentField = new JTextField(15);
        JButton searchAdherentBtn = new JButton("🔍");
        searchAdherentBtn.addActionListener(e -> searchAdherent());

        adherentCombo = new JComboBox<>();
        adherentCombo.setPreferredSize(new Dimension(250, 30));
        loadAdherents("");

        adherentPanel.add(searchAdherentField, BorderLayout.WEST);
        adherentPanel.add(searchAdherentBtn, BorderLayout.CENTER);

        gbc.gridx = 1;
        formPanel.add(adherentPanel, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        formPanel.add(new JLabel("Sélection:"), gbc);

        gbc.gridx = 1;
        formPanel.add(adherentCombo, gbc);

        // Livre
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.insets = new Insets(20, 5, 5, 5);
        formPanel.add(new JLabel("Livre *:"), gbc);

        JPanel livrePanel = new JPanel(new BorderLayout(5, 0));
        livrePanel.setBackground(Color.WHITE);

        searchLivreField = new JTextField(15);
        JButton searchLivreBtn = new JButton("🔍");
        searchLivreBtn.addActionListener(e -> searchLivre());

        livreCombo = new JComboBox<>();
        livreCombo.setPreferredSize(new Dimension(250, 30));
        loadLivres("");

        livrePanel.add(searchLivreField, BorderLayout.WEST);
        livrePanel.add(searchLivreBtn, BorderLayout.CENTER);

        gbc.gridx = 1;
        gbc.insets = new Insets(20, 5, 5, 5);
        formPanel.add(livrePanel, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.insets = new Insets(5, 5, 5, 5);
        formPanel.add(new JLabel("Sélection:"), gbc);

        gbc.gridx = 1;
        formPanel.add(livreCombo, gbc);

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        buttonPanel.setBackground(Color.WHITE);

        JButton saveButton = new JButton("Emprunter");
        saveButton.setPreferredSize(new Dimension(120, 35));
        saveButton.setBackground(new Color(46, 204, 113));
        saveButton.setForeground(Color.WHITE);
        saveButton.setFont(new Font("Arial", Font.BOLD, 12));
        saveButton.addActionListener(e -> save());

        JButton cancelButton = new JButton("Annuler");
        cancelButton.setPreferredSize(new Dimension(120, 35));
        cancelButton.setBackground(new Color(149, 165, 166));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFont(new Font("Arial", Font.BOLD, 12));
        cancelButton.addActionListener(e -> dispose());

        buttonPanel.add(saveButton);
        buttonPanel.add(cancelButton);

        mainPanel.add(formPanel, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private void loadAdherents(String keyword) {
        adherentCombo.removeAllItems();
        List<Adherent> adherents = keyword.isEmpty() ?
                adherentDAO.findAll() : adherentDAO.search(keyword);

        for (Adherent a : adherents) {
            if (!a.isBloque()) {
                adherentCombo.addItem(new AdherentItem(a));
            }
        }
    }

    private void loadLivres(String keyword) {
        livreCombo.removeAllItems();
        List<Livre> livres = keyword.isEmpty() ?
                livreDAO.findAll() : livreDAO.search(keyword);

        for (Livre l : livres) {
            if (l.estDisponible()) {
                livreCombo.addItem(new LivreItem(l));
            }
        }
    }

    private void searchAdherent() {
        loadAdherents(searchAdherentField.getText().trim());
    }

    private void searchLivre() {
        loadLivres(searchLivreField.getText().trim());
    }

    private void save() {
        try {
            AdherentItem selectedAdherent = (AdherentItem) adherentCombo.getSelectedItem();
            LivreItem selectedLivre = (LivreItem) livreCombo.getSelectedItem();

            if (selectedAdherent == null || selectedLivre == null) {
                JOptionPane.showMessageDialog(this,
                        "Veuillez sélectionner un adhérent et un livre",
                        "Erreur", JOptionPane.ERROR_MESSAGE);
                return;
            }

            empruntService.emprunterLivre(
                    selectedAdherent.adherent.getId(),
                    selectedLivre.livre.getId()
            );

            JOptionPane.showMessageDialog(this,
                    "Emprunt créé avec succès",
                    "Succès", JOptionPane.INFORMATION_MESSAGE);

            confirmed = true;
            dispose();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erreur: " + e.getMessage(),
                    "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean isConfirmed() {
        return confirmed;
    }

    // Classes internes pour ComboBox
    private static class AdherentItem {
        Adherent adherent;

        AdherentItem(Adherent adherent) {
            this.adherent = adherent;
        }

        @Override
        public String toString() {
            return adherent.getNumeroAdherent() + " - " + adherent.getNomComplet();
        }
    }

    private static class LivreItem {
        Livre livre;

        LivreItem(Livre livre) {
            this.livre = livre;
        }

        @Override
        public String toString() {
            return livre.getTitre() + " (" + livre.getExemplairesDisponibles() + " dispo)";
        }
    }
}
