package ma.estm.bibliotheque.dao.impl;

import ma.estm.bibliotheque.dao.LivreDAO;
import ma.estm.bibliotheque.model.Livre;
import ma.estm.bibliotheque.dao.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LivreDAOImpl implements LivreDAO {

    @Override
    public Livre findById(int id) {
        String sql = "SELECT l.*, c.nom as categorie_nom FROM livre l " +
                "LEFT JOIN categorie c ON l.categorie_id = c.id WHERE l.id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return mapResultSetToLivre(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public Livre findByIsbn(String isbn) {
        String sql = "SELECT l.*, c.nom as categorie_nom FROM livre l " +
                "LEFT JOIN categorie c ON l.categorie_id = c.id WHERE l.isbn = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, isbn);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return mapResultSetToLivre(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Livre> findAll() {
        List<Livre> livres = new ArrayList<>();
        String sql = "SELECT l.*, c.nom as categorie_nom FROM livre l " +
                "LEFT JOIN categorie c ON l.categorie_id = c.id ORDER BY l.titre";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                livres.add(mapResultSetToLivre(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return livres;
    }

    @Override
    public List<Livre> search(String keyword) {
        List<Livre> livres = new ArrayList<>();
        String sql = "SELECT l.*, c.nom as categorie_nom FROM livre l " +
                "LEFT JOIN categorie c ON l.categorie_id = c.id " +
                "WHERE LOWER(l.titre) LIKE ? OR LOWER(l.auteur) LIKE ? OR " +
                "LOWER(l.isbn) LIKE ? ORDER BY l.titre";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            String pattern = "%" + keyword.toLowerCase() + "%";
            stmt.setString(1, pattern);
            stmt.setString(2, pattern);
            stmt.setString(3, pattern);

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                livres.add(mapResultSetToLivre(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return livres;
    }

    @Override
    public List<Livre> findByCategorie(int categorieId) {
        List<Livre> livres = new ArrayList<>();
        String sql = "SELECT l.*, c.nom as categorie_nom FROM livre l " +
                "LEFT JOIN categorie c ON l.categorie_id = c.id " +
                "WHERE l.categorie_id = ? ORDER BY l.titre";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, categorieId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                livres.add(mapResultSetToLivre(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return livres;
    }

    @Override
    public void save(Livre livre) {
        String sql = "INSERT INTO livre (isbn, titre, auteur, editeur, annee_publication, " +
                "nombre_exemplaires, exemplaires_disponibles, categorie_id) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, livre.getIsbn());
            stmt.setString(2, livre.getTitre());
            stmt.setString(3, livre.getAuteur());
            stmt.setString(4, livre.getEditeur());
            stmt.setInt(5, livre.getAnneePublication());
            stmt.setInt(6, livre.getNombreExemplaires());
            stmt.setInt(7, livre.getExemplairesDisponibles());

            if (livre.getCategorieId() > 0) {
                stmt.setInt(8, livre.getCategorieId());
            } else {
                stmt.setNull(8, Types.INTEGER);
            }

            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                livre.setId(rs.getInt(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(Livre livre) {
        String sql = "UPDATE livre SET isbn = ?, titre = ?, auteur = ?, editeur = ?, " +
                "annee_publication = ?, nombre_exemplaires = ?, " +
                "exemplaires_disponibles = ?, categorie_id = ? WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, livre.getIsbn());
            stmt.setString(2, livre.getTitre());
            stmt.setString(3, livre.getAuteur());
            stmt.setString(4, livre.getEditeur());
            stmt.setInt(5, livre.getAnneePublication());
            stmt.setInt(6, livre.getNombreExemplaires());
            stmt.setInt(7, livre.getExemplairesDisponibles());

            if (livre.getCategorieId() > 0) {
                stmt.setInt(8, livre.getCategorieId());
            } else {
                stmt.setNull(8, Types.INTEGER);
            }

            stmt.setInt(9, livre.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(int id) {
        String sql = "DELETE FROM livre WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean hasActiveEmprunts(int livreId) {
        String sql = "SELECT COUNT(*) FROM emprunt WHERE livre_id = ? AND statut = 'EN_COURS'";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, livreId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private Livre mapResultSetToLivre(ResultSet rs) throws SQLException {
        Livre livre = new Livre();
        livre.setId(rs.getInt("id"));
        livre.setIsbn(rs.getString("isbn"));
        livre.setTitre(rs.getString("titre"));
        livre.setAuteur(rs.getString("auteur"));
        livre.setEditeur(rs.getString("editeur"));
        livre.setAnneePublication(rs.getInt("annee_publication"));
        livre.setNombreExemplaires(rs.getInt("nombre_exemplaires"));
        livre.setExemplairesDisponibles(rs.getInt("exemplaires_disponibles"));

        int catId = rs.getInt("categorie_id");
        if (!rs.wasNull()) {
            livre.setCategorieId(catId);
            livre.setCategorieNom(rs.getString("categorie_nom"));
        }

        return livre;
    }
}
