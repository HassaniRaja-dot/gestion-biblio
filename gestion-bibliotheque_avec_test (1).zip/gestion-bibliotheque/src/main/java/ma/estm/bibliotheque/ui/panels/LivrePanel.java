package ma.estm.bibliotheque.ui.panels;

import ma.estm.bibliotheque.model.Livre;
import ma.estm.bibliotheque.service.AuthenticationService;
import ma.estm.bibliotheque.service.LivreService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class LivrePanel extends JPanel {
    private LivreService livreService;
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField searchField;

    public LivrePanel() {
        livreService = new LivreService();
        initComponents();
        loadLivres();
    }

    private void initComponents() {
        setLayout(new BorderLayout(5, 5));

        // Top - Search
        JPanel topPanel = new JPanel();
        topPanel.add(new JLabel("Recherche:"));
        searchField = new JTextField(20);
        topPanel.add(searchField);
        JButton searchBtn = new JButton("Chercher");
        searchBtn.addActionListener(e -> searchLivres());
        topPanel.add(searchBtn);
        JButton refreshBtn = new JButton("Actualiser");
        refreshBtn.addActionListener(e -> loadLivres());
        topPanel.add(refreshBtn);
        add(topPanel, BorderLayout.NORTH);

        // Center - Table
        String[] columns = {"ID", "ISBN", "Titre", "Auteur", "Disponibles"};
        tableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int column) { return false; }
        };
        table = new JTable(tableModel);

        // Cacher la colonne ID pour les users
        if (!AuthenticationService.isAdmin()) {
            table.getColumnModel().getColumn(0).setMinWidth(0);
            table.getColumnModel().getColumn(0).setMaxWidth(0);
        }

        add(new JScrollPane(table), BorderLayout.CENTER);

        // Bottom - Buttons (Admin only)
        if (AuthenticationService.isAdmin()) {
            JPanel btnPanel = new JPanel();
            JButton addBtn = new JButton("Ajouter");
            addBtn.addActionListener(e -> ajouterLivre());
            btnPanel.add(addBtn);
            JButton editBtn = new JButton("Modifier");
            editBtn.addActionListener(e -> modifierLivre());
            btnPanel.add(editBtn);
            JButton delBtn = new JButton("Supprimer");
            delBtn.addActionListener(e -> supprimerLivre());
            btnPanel.add(delBtn);
            add(btnPanel, BorderLayout.SOUTH);
        }
    }

    private void loadLivres() {
        tableModel.setRowCount(0);
        for (Livre l : livreService.getAllLivres()) {
            tableModel.addRow(new Object[]{
                    l.getId(), l.getIsbn(), l.getTitre(), l.getAuteur(), l.getExemplairesDisponibles()
            });
        }
    }

    private void searchLivres() {
        tableModel.setRowCount(0);
        for (Livre l : livreService.searchLivres(searchField.getText())) {
            tableModel.addRow(new Object[]{
                    l.getId(), l.getIsbn(), l.getTitre(), l.getAuteur(), l.getExemplairesDisponibles()
            });
        }
    }

    private void ajouterLivre() {
        String isbn = JOptionPane.showInputDialog("ISBN:");
        if (isbn == null) return;
        String titre = JOptionPane.showInputDialog("Titre:");
        if (titre == null) return;
        String auteur = JOptionPane.showInputDialog("Auteur:");
        if (auteur == null) return;
        String nb = JOptionPane.showInputDialog("Nombre d'exemplaires:");
        if (nb == null) return;

        try {
            Livre livre = new Livre(isbn, titre, auteur, Integer.parseInt(nb));
            livreService.ajouterLivre(livre);
            JOptionPane.showMessageDialog(this, "Livre ajouté!");
            loadLivres();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erreur: " + e.getMessage());
        }
    }

    private void modifierLivre() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Sélectionnez un livre");
            return;
        }
        int id = (int) tableModel.getValueAt(row, 0);
        Livre livre = livreService.getLivreById(id);

        livre.setTitre(JOptionPane.showInputDialog("Titre:", livre.getTitre()));
        livre.setAuteur(JOptionPane.showInputDialog("Auteur:", livre.getAuteur()));

        try {
            livreService.modifierLivre(livre);
            JOptionPane.showMessageDialog(this, "Livre modifié!");
            loadLivres();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erreur: " + e.getMessage());
        }
    }

    private void supprimerLivre() {
        int row = table.getSelectedRow();
        if (row == -1) return;

        int choice = JOptionPane.showConfirmDialog(this, "Supprimer ce livre?");
        if (choice == JOptionPane.YES_OPTION) {
            try {
                int id = (int) tableModel.getValueAt(row, 0);
                livreService.supprimerLivre(id);
                JOptionPane.showMessageDialog(this, "Livre supprimé!");
                loadLivres();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Erreur: " + e.getMessage());
            }
        }
    }
}