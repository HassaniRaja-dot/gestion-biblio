package ma.estm.bibliotheque.dao;

import ma.estm.bibliotheque.model.Livre;
import java.util.List;

public interface LivreDAO {
    Livre findById(int id);
    Livre findByIsbn(String isbn);
    List<Livre> findAll();
    List<Livre> search(String keyword);
    List<Livre> findByCategorie(int categorieId);
    void save(Livre livre);
    void update(Livre livre);
    void delete(int id);
    boolean hasActiveEmprunts(int livreId);
}
