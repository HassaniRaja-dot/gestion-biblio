package ma.estm.bibliotheque.ui.panels;



import ma.estm.bibliotheque.model.Emprunt;
import ma.estm.bibliotheque.model.StatutEmprunt;
import ma.estm.bibliotheque.service.AuthenticationService;
import ma.estm.bibliotheque.service.EmpruntService;
import ma.estm.bibliotheque.util.DateUtil;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class MesEmpruntsPanel extends JPanel {
    private EmpruntService empruntService;
    private JTable table;
    private DefaultTableModel tableModel;
    private JComboBox<String> filtreStatutCombo;
    private JLabel statsLabel;

    public MesEmpruntsPanel() {
        empruntService = new EmpruntService();
        initComponents();
        loadMesEmprunts();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Panel du haut
        JPanel topPanel = new JPanel(new BorderLayout());

        // Titre
        JLabel titleLabel = new JLabel("Mes Emprunts");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        topPanel.add(titleLabel, BorderLayout.NORTH);

        // Panel de filtres
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filterPanel.add(new JLabel("Filtrer par statut:"));

        filtreStatutCombo = new JComboBox<>(new String[]{
                "Tous", "En cours", "Retournés", "En retard"
        });
        filtreStatutCombo.addActionListener(e -> filtrerEmprunts());
        filterPanel.add(filtreStatutCombo);

        JButton refreshButton = new JButton("Actualiser");
        refreshButton.addActionListener(e -> loadMesEmprunts());
        filterPanel.add(refreshButton);

        topPanel.add(filterPanel, BorderLayout.CENTER);

        // Statistiques
        statsLabel = new JLabel();
        statsLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        topPanel.add(statsLabel, BorderLayout.SOUTH);

        add(topPanel, BorderLayout.NORTH);

        // Tableau
        String[] columns = {"ID", "Livre", "Date Emprunt", "Date Retour Prévue",
                "Date Retour Effective", "Statut", "Jours de Retard"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setRowHeight(25);

        // Largeurs des colonnes
        table.getColumnModel().getColumn(0).setPreferredWidth(50);
        table.getColumnModel().getColumn(1).setPreferredWidth(250);
        table.getColumnModel().getColumn(2).setPreferredWidth(100);
        table.getColumnModel().getColumn(3).setPreferredWidth(100);
        table.getColumnModel().getColumn(4).setPreferredWidth(100);
        table.getColumnModel().getColumn(5).setPreferredWidth(100);
        table.getColumnModel().getColumn(6).setPreferredWidth(100);

        JScrollPane scrollPane = new JScrollPane(table);
        add(scrollPane, BorderLayout.CENTER);

        // Panel d'informations
        JPanel infoPanel = createInfoPanel();
        add(infoPanel, BorderLayout.SOUTH);
    }

    private JPanel createInfoPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Informations"));

        JTextArea infoArea = new JTextArea(4, 40);
        infoArea.setEditable(false);
        infoArea.setText(
                "📚 Informations importantes:\n" +
                        "• Vous pouvez emprunter jusqu'à 3 livres simultanément\n" +
                        "• Durée d'emprunt: 14 jours\n" +
                        "• Au-delà de 10 jours de retard, votre compte sera bloqué\n" +
                        "• Contactez la bibliothèque pour tout problème"
        );

        JScrollPane scrollPane = new JScrollPane(infoArea);
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private void loadMesEmprunts() {
        tableModel.setRowCount(0);

        try {
            // Récupérer l'utilisateur connecté
            int userId = AuthenticationService.getCurrentUser().getId();

            // Si l'utilisateur est lié à un adhérent
            Integer adherentId = AuthenticationService.getCurrentUser().getAdherentId();

            if (adherentId == null) {
                JOptionPane.showMessageDialog(this,
                        "Aucun adhérent associé à ce compte",
                        "Information", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            List<Emprunt> emprunts = empruntService.getEmpruntsByAdherent(adherentId);

            int nbEnCours = 0;
            int nbRetournes = 0;
            int nbEnRetard = 0;

            for (Emprunt emprunt : emprunts) {
                int joursRetard = emprunt.joursRetard();

                tableModel.addRow(new Object[]{
                        emprunt.getId(),
                        emprunt.getLivreTitre(),
                        DateUtil.formatDate(emprunt.getDateEmprunt()),
                        DateUtil.formatDate(emprunt.getDateRetourPrevue()),
                        DateUtil.formatDate(emprunt.getDateRetourEffective()),
                        emprunt.getStatut(),
                        joursRetard > 0 ? joursRetard + " jours" : "-"
                });

                // Compter les statuts
                if (emprunt.getStatut() == StatutEmprunt.EN_COURS) {
                    if (joursRetard > 0) {
                        nbEnRetard++;
                    } else {
                        nbEnCours++;
                    }
                } else {
                    nbRetournes++;
                }
            }

            // Mettre à jour les statistiques
            updateStats(nbEnCours, nbRetournes, nbEnRetard);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erreur lors du chargement: " + e.getMessage(),
                    "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void filtrerEmprunts() {
        String filtre = (String) filtreStatutCombo.getSelectedItem();
        tableModel.setRowCount(0);

        try {
            Integer adherentId = AuthenticationService.getCurrentUser().getAdherentId();

            if (adherentId == null) {
                return;
            }

            List<Emprunt> emprunts = empruntService.getEmpruntsByAdherent(adherentId);

            for (Emprunt emprunt : emprunts) {
                boolean afficher = false;

                switch (filtre) {
                    case "Tous":
                        afficher = true;
                        break;
                    case "En cours":
                        afficher = emprunt.getStatut() == StatutEmprunt.EN_COURS
                                && !emprunt.verifierRetard();
                        break;
                    case "Retournés":
                        afficher = emprunt.getStatut() == StatutEmprunt.RETOURNE;
                        break;
                    case "En retard":
                        afficher = emprunt.getStatut() == StatutEmprunt.EN_COURS
                                && emprunt.verifierRetard();
                        break;
                }

                if (afficher) {
                    int joursRetard = emprunt.joursRetard();

                    tableModel.addRow(new Object[]{
                            emprunt.getId(),
                            emprunt.getLivreTitre(),
                            DateUtil.formatDate(emprunt.getDateEmprunt()),
                            DateUtil.formatDate(emprunt.getDateRetourPrevue()),
                            DateUtil.formatDate(emprunt.getDateRetourEffective()),
                            emprunt.getStatut(),
                            joursRetard > 0 ? joursRetard + " jours" : "-"
                    });
                }
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erreur lors du filtrage: " + e.getMessage(),
                    "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateStats(int nbEnCours, int nbRetournes, int nbEnRetard) {
        int total = nbEnCours + nbRetournes + nbEnRetard;
        int limiteRestante = 3 - (nbEnCours + nbEnRetard);

        String statsText = String.format(
                "Total: %d emprunts | En cours: %d | Retournés: %d | En retard: %d | " +
                        "Emprunts disponibles: %d/3",
                total, nbEnCours, nbRetournes, nbEnRetard, limiteRestante
        );

        statsLabel.setText(statsText);

        // Changer la couleur si en retard
        if (nbEnRetard > 0) {
            statsLabel.setForeground(Color.RED);
        } else if (limiteRestante == 0) {
            statsLabel.setForeground(Color.ORANGE);
        } else {
            statsLabel.setForeground(Color.BLACK);
        }
    }
}