package ma.estm.bibliotheque.model;

import java.util.Calendar;
import java.util.Date;

public class Emprunt {
    private int id;
    private int adherentId;
    private int livreId;
    private Date dateEmprunt;
    private Date dateRetourPrevue;
    private Date dateRetourEffective;
    private StatutEmprunt statut;

    // Champs supplémentaires pour l'affichage
    private String adherentNom;
    private String livreTitre;

    public Emprunt() {
        this.dateEmprunt = new Date();
        this.dateRetourPrevue = calculerRetourPrevu();
        this.statut = StatutEmprunt.EN_COURS;
    }

    public Emprunt(int adherentId, int livreId) {
        this();
        this.adherentId = adherentId;
        this.livreId = livreId;
    }

    public Date calculerRetourPrevu() {
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.add(Calendar.DAY_OF_MONTH, 14); // 14 jours de prêt
        return cal.getTime();
    }

    public boolean verifierRetard() {
        if (statut == StatutEmprunt.RETOURNE) {
            return false;
        }
        Date now = new Date();
        return now.after(dateRetourPrevue);
    }

    public int joursRetard() {
        if (!verifierRetard()) {
            return 0;
        }
        Date now = dateRetourEffective != null ? dateRetourEffective : new Date();
        long diff = now.getTime() - dateRetourPrevue.getTime();
        return (int) (diff / (1000 * 60 * 60 * 24));
    }

    public void cloturer() {
        this.dateRetourEffective = new Date();
        this.statut = verifierRetard() ? StatutEmprunt.EN_RETARD : StatutEmprunt.RETOURNE;
    }

    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getAdherentId() { return adherentId; }
    public void setAdherentId(int adherentId) { this.adherentId = adherentId; }

    public int getLivreId() { return livreId; }
    public void setLivreId(int livreId) { this.livreId = livreId; }

    public Date getDateEmprunt() { return dateEmprunt; }
    public void setDateEmprunt(Date dateEmprunt) { this.dateEmprunt = dateEmprunt; }

    public Date getDateRetourPrevue() { return dateRetourPrevue; }
    public void setDateRetourPrevue(Date dateRetourPrevue) {
        this.dateRetourPrevue = dateRetourPrevue;
    }

    public Date getDateRetourEffective() { return dateRetourEffective; }
    public void setDateRetourEffective(Date dateRetourEffective) {
        this.dateRetourEffective = dateRetourEffective;
    }

    public StatutEmprunt getStatut() { return statut; }
    public void setStatut(StatutEmprunt statut) { this.statut = statut; }

    public String getAdherentNom() { return adherentNom; }
    public void setAdherentNom(String adherentNom) { this.adherentNom = adherentNom; }

    public String getLivreTitre() { return livreTitre; }
    public void setLivreTitre(String livreTitre) { this.livreTitre = livreTitre; }
}