package ma.estm.bibliotheque.ui;

import ma.estm.bibliotheque.model.Utilisateur;
import ma.estm.bibliotheque.service.AuthenticationService;

import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {
    private JTextField loginField;
    private JPasswordField passwordField;
    private AuthenticationService authService;

    public LoginFrame() {
        authService = new AuthenticationService();
        initComponents();
    }

    private void initComponents() {
        setTitle("Connexion - Bibliothèque");
        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridLayout(3, 2, 5, 5));

        panel.add(new JLabel("Login:"));
        loginField = new JTextField();
        panel.add(loginField);

        panel.add(new JLabel("Mot de passe:"));
        passwordField = new JPasswordField();
        panel.add(passwordField);

        JButton loginButton = new JButton("Connexion");
        loginButton.addActionListener(e -> login());
        panel.add(loginButton);

        JButton quitButton = new JButton("Quitter");
        quitButton.addActionListener(e -> System.exit(0));
        panel.add(quitButton);

        add(panel);

        // Touche Entrée pour se connecter
        passwordField.addActionListener(e -> login());
    }

    private void login() {
        String login = loginField.getText().trim();
        String password = new String(passwordField.getPassword());

        if (login.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Remplissez tous les champs");
            return;
        }

        try {
            Utilisateur user = authService.authenticate(login, password);

            if (user != null) {
                dispose();
                SwingUtilities.invokeLater(() -> {
                    MainFrame mainFrame = new MainFrame();
                    mainFrame.setVisible(true);
                });
            } else {
                JOptionPane.showMessageDialog(this, "Login ou mot de passe incorrect");
                passwordField.setText("");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erreur: " + e.getMessage());
        }
    }
}