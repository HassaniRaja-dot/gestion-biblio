package ma.estm.bibliotheque.service;

import ma.estm.bibliotheque.dao.AdherentDAO;
import ma.estm.bibliotheque.dao.impl.AdherentDAOImpl;
import ma.estm.bibliotheque.model.Adherent;
import ma.estm.bibliotheque.util.ValidationUtil;

import java.util.List;
import java.util.Random;

public class AdherentService {
    private AdherentDAO adherentDAO;
    private LogService logService;

    public AdherentService() {
        this.adherentDAO = new AdherentDAOImpl();
        this.logService = new LogService();
    }

    public List<Adherent> getAllAdherents() {
        return adherentDAO.findAll();
    }

    public List<Adherent> searchAdherents(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllAdherents();
        }
        return adherentDAO.search(keyword);
    }

    public void ajouterAdherent(Adherent adherent) throws Exception {
        // Validations
        if (!ValidationUtil.isNotEmpty(adherent.getNom())) {
            throw new Exception("Nom obligatoire");
        }
        if (!ValidationUtil.isNotEmpty(adherent.getPrenom())) {
            throw new Exception("Prénom obligatoire");
        }
        if (!ValidationUtil.isValidEmail(adherent.getEmail())) {
            throw new Exception("Email invalide");
        }

        // Vérifier email unique
        if (adherentDAO.findByEmail(adherent.getEmail()) != null) {
            throw new Exception("Email déjà utilisé");
        }

        // Générer numéro adhérent unique
        adherent.setNumeroAdherent(genererNumeroAdherent());

        adherentDAO.save(adherent);
        logService.log("AJOUT_ADHERENT", "Adhérent ajouté: " + adherent.getNomComplet());
    }

    public void modifierAdherent(Adherent adherent) throws Exception {
        if (!ValidationUtil.isNotEmpty(adherent.getNom())) {
            throw new Exception("Nom obligatoire");
        }
        if (!ValidationUtil.isNotEmpty(adherent.getPrenom())) {
            throw new Exception("Prénom obligatoire");
        }
        if (!ValidationUtil.isValidEmail(adherent.getEmail())) {
            throw new Exception("Email invalide");
        }

        adherentDAO.update(adherent);
        logService.log("MODIF_ADHERENT", "Adhérent modifié: " + adherent.getNomComplet());
    }

    public void supprimerAdherent(int id) throws Exception {
        // Vérifier s'il y a des emprunts actifs
        int nbEmprunts = adherentDAO.countEmpruntsActifs(id);
        if (nbEmprunts > 0) {
            throw new Exception("Impossible de supprimer: emprunts en cours");
        }

        Adherent adherent = adherentDAO.findById(id);
        adherentDAO.delete(id);

        if (adherent != null) {
            logService.log("SUPPRESSION_ADHERENT",
                    "Adhérent supprimé: " + adherent.getNomComplet());
        }
    }

    private String genererNumeroAdherent() {
        Random random = new Random();
        String numero;
        do {
            numero = "ADH" + String.format("%06d", random.nextInt(1000000));
        } while (adherentDAO.findByNumero(numero) != null);
        return numero;
    }
}
