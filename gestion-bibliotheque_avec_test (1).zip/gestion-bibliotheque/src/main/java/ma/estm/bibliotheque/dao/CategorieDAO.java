package ma.estm.bibliotheque.dao;

import ma.estm.bibliotheque.model.Categorie;
import java.util.List;

public interface CategorieDAO {
    Categorie findById(int id);

    Categorie findByNom(String nom);

    List<Categorie> findAll();

    void save(Categorie categorie);

    void update(Categorie categorie);

    void delete(int id);
}
