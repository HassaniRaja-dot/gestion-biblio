package ma.estm.bibliotheque.model;

public class Utilisateur {
    private int id;
    private String login;
    private String motDePasseHache;
    private Role role;
    private boolean actif;
    private Integer adherentId; // Lien avec Adherent si USER

    public Utilisateur() {}

    public Utilisateur(String login, String motDePasseHache, Role role) {
        this.login = login;
        this.motDePasseHache = motDePasseHache;
        this.role = role;
        this.actif = true;
    }

    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getLogin() { return login; }
    public void setLogin(String login) { this.login = login; }

    public String getMotDePasseHache() { return motDePasseHache; }
    public void setMotDePasseHache(String motDePasseHache) {
        this.motDePasseHache = motDePasseHache;
    }

    public Role getRole() { return role; }
    public void setRole(Role role) { this.role = role; }

    public boolean isActif() { return actif; }
    public void setActif(boolean actif) { this.actif = actif; }

    public Integer getAdherentId() { return adherentId; }
    public void setAdherentId(Integer adherentId) { this.adherentId = adherentId; }
}
