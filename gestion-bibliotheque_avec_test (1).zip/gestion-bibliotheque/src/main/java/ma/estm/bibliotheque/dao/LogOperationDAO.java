package ma.estm.bibliotheque.dao;

import ma.estm.bibliotheque.model.LogOperation;
import java.util.List;

public interface LogOperationDAO {
    List<LogOperation> findAll();
    List<LogOperation> findByUser(int userId);
    List<LogOperation> findRecent(int limit);
    void save(LogOperation log);
}
