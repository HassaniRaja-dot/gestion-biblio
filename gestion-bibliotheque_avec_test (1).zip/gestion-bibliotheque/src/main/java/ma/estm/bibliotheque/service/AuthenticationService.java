package ma.estm.bibliotheque.service;

import ma.estm.bibliotheque.dao.UtilisateurDAO;
import ma.estm.bibliotheque.dao.impl.UtilisateurDAOImpl;
import ma.estm.bibliotheque.model.Utilisateur;
import ma.estm.bibliotheque.util.PasswordUtil;

public class AuthenticationService {
    private UtilisateurDAO utilisateurDAO;
    private static Utilisateur currentUser = null;

    public AuthenticationService() {
        this.utilisateurDAO = new UtilisateurDAOImpl();
    }

    public Utilisateur authenticate(String login, String password) {
        Utilisateur user = utilisateurDAO.findByLogin(login);

        if (user == null) {
            return null;
        }

        if (!user.isActif()) {
            throw new RuntimeException("Compte désactivé");
        }

        if (PasswordUtil.verifyPassword(password, user.getMotDePasseHache())) {
            currentUser = user;
            return user;
        }

        return null;
    }

    public static Utilisateur getCurrentUser() {
        return currentUser;
    }

    public static void logout() {
        currentUser = null;
    }

    public static boolean isAdmin() {
        return currentUser != null &&
                currentUser.getRole() == ma.estm.bibliotheque.model.Role.ADMIN;
    }
}