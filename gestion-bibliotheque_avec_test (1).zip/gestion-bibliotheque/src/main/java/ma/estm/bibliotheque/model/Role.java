package ma.estm.bibliotheque.model;
public enum Role {
    ADMIN, USER
}
