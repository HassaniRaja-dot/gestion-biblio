package ma.estm.bibliotheque.ui;

import ma.estm.bibliotheque.service.AuthenticationService;
import ma.estm.bibliotheque.ui.panels.*;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    private JPanel contentPanel;
    private CardLayout cardLayout;

    public MainFrame() {
        initComponents();
    }

    private void initComponents() {
        setTitle("Bibliothèque - " + AuthenticationService.getCurrentUser().getLogin());
        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Menu
        JMenuBar menuBar = new JMenuBar();

        JMenu dashboardMenu = new JMenu("Accueil");
        JMenuItem dashItem = new JMenuItem("Tableau de bord");
        dashItem.addActionListener(e -> showPanel("DASHBOARD"));
        dashboardMenu.add(dashItem);
        menuBar.add(dashboardMenu);

        JMenu catalogueMenu = new JMenu("Catalogue");
        JMenuItem livresItem = new JMenuItem("Livres");
        livresItem.addActionListener(e -> showPanel("LIVRES"));
        catalogueMenu.add(livresItem);
        menuBar.add(catalogueMenu);

        if (AuthenticationService.isAdmin()) {
            JMenu adherentsMenu = new JMenu("Adhérents");
            JMenuItem adhItem = new JMenuItem("Gérer adhérents");
            adhItem.addActionListener(e -> showPanel("ADHERENTS"));
            adherentsMenu.add(adhItem);
            menuBar.add(adherentsMenu);

            JMenu empruntsMenu = new JMenu("Emprunts");
            JMenuItem empItem = new JMenuItem("Gérer emprunts");
            empItem.addActionListener(e -> showPanel("EMPRUNTS"));
            empruntsMenu.add(empItem);
            menuBar.add(empruntsMenu);

            JMenu utilisateursMenu = new JMenu("Utilisateurs");
            JMenuItem userItem = new JMenuItem("Gérer utilisateurs");
            userItem.addActionListener(e -> showPanel("UTILISATEURS"));
            utilisateursMenu.add(userItem);
            menuBar.add(utilisateursMenu);
        } else {
            JMenu empruntMenu = new JMenu("Emprunter");
            JMenuItem faireEmpruntItem = new JMenuItem("Faire un emprunt");
            faireEmpruntItem.addActionListener(e -> showPanel("FAIRE_EMPRUNT"));
            empruntMenu.add(faireEmpruntItem);
            menuBar.add(empruntMenu);

            JMenu mesEmpruntsMenu = new JMenu("Mes Emprunts");
            JMenuItem mesEmpItem = new JMenuItem("Voir mes emprunts");
            mesEmpItem.addActionListener(e -> showPanel("MES_EMPRUNTS"));
            mesEmpruntsMenu.add(mesEmpItem);
            menuBar.add(mesEmpruntsMenu);
        }

        JMenu compteMenu = new JMenu("Compte");
        JMenuItem logoutItem = new JMenuItem("Déconnexion");
        logoutItem.addActionListener(e -> logout());
        compteMenu.add(logoutItem);
        menuBar.add(compteMenu);

        setJMenuBar(menuBar);

        // Content avec CardLayout
        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);

        contentPanel.add(new DashboardPanel(), "DASHBOARD");
        contentPanel.add(new LivrePanel(), "LIVRES");

        if (AuthenticationService.isAdmin()) {
            contentPanel.add(new AdherentPanel(), "ADHERENTS");
            contentPanel.add(new EmpruntPanel(), "EMPRUNTS");
            contentPanel.add(new UtilisateurPanel(), "UTILISATEURS");
        } else {
            contentPanel.add(new FaireEmpruntPanel(), "FAIRE_EMPRUNT");
            contentPanel.add(new MesEmpruntsPanel(), "MES_EMPRUNTS");
        }

        add(contentPanel);

        cardLayout.show(contentPanel, "DASHBOARD");
    }

    private void showPanel(String panelName) {
        cardLayout.show(contentPanel, panelName);
    }

    private void logout() {
        int choice = JOptionPane.showConfirmDialog(this, "Déconnexion?");
        if (choice == JOptionPane.YES_OPTION) {
            AuthenticationService.logout();
            dispose();
            SwingUtilities.invokeLater(() -> {
                LoginFrame loginFrame = new LoginFrame();
                loginFrame.setVisible(true);
            });
        }
    }
}