package ma.estm.bibliotheque.dao;

import ma.estm.bibliotheque.model.Emprunt;
import ma.estm.bibliotheque.model.StatutEmprunt;
import java.util.List;

public interface EmpruntDAO {
    Emprunt findById(int id);
    List<Emprunt> findAll();
    List<Emprunt> findByAdherent(int adherentId);
    List<Emprunt> findByStatut(StatutEmprunt statut);
    List<Emprunt> findEmpruntsEnRetard();
    void save(Emprunt emprunt);
    void update(Emprunt emprunt);
    void delete(int id);
}
