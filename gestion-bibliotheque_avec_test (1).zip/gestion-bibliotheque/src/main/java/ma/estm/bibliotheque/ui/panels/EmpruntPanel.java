package ma.estm.bibliotheque.ui.panels;

import ma.estm.bibliotheque.model.Emprunt;
import ma.estm.bibliotheque.service.EmpruntService;
import ma.estm.bibliotheque.util.DateUtil;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class EmpruntPanel extends JPanel {
    private EmpruntService empruntService;
    private JTable table;
    private DefaultTableModel tableModel;

    public EmpruntPanel() {
        empruntService = new EmpruntService();
        initComponents();
        loadEmprunts();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        setBackground(Color.WHITE);

        // Header
        JLabel titleLabel = new JLabel("Gestion des Emprunts");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));

        // Table
        String[] columns = {"ID", "Adhérent", "Livre", "Date Emprunt",
                "Date Retour Prévue", "Date Retour Effective", "Statut"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setRowHeight(25);
        table.getColumnModel().getColumn(1).setPreferredWidth(150);
        table.getColumnModel().getColumn(2).setPreferredWidth(200);

        JScrollPane scrollPane = new JScrollPane(table);

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.setBackground(Color.WHITE);

        JButton addButton = createButton("Nouvel Emprunt", new Color(46, 204, 113));
        addButton.addActionListener(e -> nouvelEmprunt());

        JButton returnButton = createButton("Retourner", new Color(52, 152, 219));
        returnButton.addActionListener(e -> retournerLivre());

        JButton refreshButton = createButton("Actualiser", new Color(149, 165, 166));
        refreshButton.addActionListener(e -> loadEmprunts());

        buttonPanel.add(addButton);
        buttonPanel.add(returnButton);
        buttonPanel.add(refreshButton);

        add(titleLabel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private JButton createButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(140, 35));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 12));
        button.setFocusPainted(false);
        return button;
    }

    private void loadEmprunts() {
        tableModel.setRowCount(0);
        List<Emprunt> emprunts = empruntService.getAllEmprunts();

        for (Emprunt emprunt : emprunts) {
            tableModel.addRow(new Object[]{
                    emprunt.getId(),
                    emprunt.getAdherentNom(),
                    emprunt.getLivreTitre(),
                    DateUtil.formatDate(emprunt.getDateEmprunt()),
                    DateUtil.formatDate(emprunt.getDateRetourPrevue()),
                    DateUtil.formatDate(emprunt.getDateRetourEffective()),
                    emprunt.getStatut()
            });
        }
    }

    private void nouvelEmprunt() {
        EmpruntDialog dialog = new EmpruntDialog(
                (Frame) SwingUtilities.getWindowAncestor(this), empruntService);
        dialog.setVisible(true);
        if (dialog.isConfirmed()) {
            loadEmprunts();
        }
    }

    private void retournerLivre() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                    "Veuillez sélectionner un emprunt",
                    "Information", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        int empruntId = (int) tableModel.getValueAt(selectedRow, 0);

        try {
            empruntService.retournerLivre(empruntId);
            JOptionPane.showMessageDialog(this,
                    "Livre retourné avec succès",
                    "Succès", JOptionPane.INFORMATION_MESSAGE);
            loadEmprunts();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erreur: " + e.getMessage(),
                    "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }
}
