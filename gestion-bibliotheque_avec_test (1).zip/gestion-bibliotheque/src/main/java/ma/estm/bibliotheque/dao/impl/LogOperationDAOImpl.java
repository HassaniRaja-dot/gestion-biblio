package ma.estm.bibliotheque.dao.impl;

import ma.estm.bibliotheque.dao.LogOperationDAO;
import ma.estm.bibliotheque.model.LogOperation;
import ma.estm.bibliotheque.dao.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LogOperationDAOImpl implements LogOperationDAO {

    @Override
    public List<LogOperation> findAll() {
        List<LogOperation> logs = new ArrayList<>();
        String sql = "SELECT l.*, u.login as user_login FROM log_operation l " +
                "JOIN utilisateur u ON l.user_id = u.id " +
                "ORDER BY l.date_operation DESC";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                logs.add(mapResultSetToLog(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return logs;
    }

    @Override
    public List<LogOperation> findByUser(int userId) {
        List<LogOperation> logs = new ArrayList<>();
        String sql = "SELECT l.*, u.login as user_login FROM log_operation l " +
                "JOIN utilisateur u ON l.user_id = u.id " +
                "WHERE l.user_id = ? " +
                "ORDER BY l.date_operation DESC";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                logs.add(mapResultSetToLog(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return logs;
    }

    @Override
    public List<LogOperation> findRecent(int limit) {
        List<LogOperation> logs = new ArrayList<>();
        String sql = "SELECT l.*, u.login as user_login FROM log_operation l " +
                "JOIN utilisateur u ON l.user_id = u.id " +
                "ORDER BY l.date_operation DESC LIMIT ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, limit);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                logs.add(mapResultSetToLog(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return logs;
    }

    @Override
    public void save(LogOperation log) {
        String sql = "INSERT INTO log_operation (date_operation, type_operation, " +
                "description, user_id) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setTimestamp(1, new Timestamp(log.getDateOperation().getTime()));
            stmt.setString(2, log.getTypeOperation());
            stmt.setString(3, log.getDescription());
            stmt.setInt(4, log.getUserId());

            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                log.setId(rs.getInt(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private LogOperation mapResultSetToLog(ResultSet rs) throws SQLException {
        LogOperation log = new LogOperation();
        log.setId(rs.getInt("id"));
        log.setDateOperation(rs.getTimestamp("date_operation"));
        log.setTypeOperation(rs.getString("type_operation"));
        log.setDescription(rs.getString("description"));
        log.setUserId(rs.getInt("user_id"));
        log.setUserLogin(rs.getString("user_login"));
        return log;
    }
}