package ma.estm.bibliotheque.model;

public enum StatutEmprunt {
    EN_COURS, RETOURNE, EN_RETARD
}