package ma.estm.bibliotheque.service;

import ma.estm.bibliotheque.dao.LivreDAO;
import ma.estm.bibliotheque.dao.impl.LivreDAOImpl;
import ma.estm.bibliotheque.model.Livre;
import ma.estm.bibliotheque.util.ValidationUtil;

import java.util.List;

public class LivreService {
    private LivreDAO livreDAO;
    private LogService logService;

    public LivreService() {
        this.livreDAO = new LivreDAOImpl();
        this.logService = new LogService();
    }

    public List<Livre> getAllLivres() {
        return livreDAO.findAll();
    }

    public List<Livre> searchLivres(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllLivres();
        }
        return livreDAO.search(keyword);
    }

    public Livre getLivreById(int id) {
        return livreDAO.findById(id);
    }

    public void ajouterLivre(Livre livre) throws Exception {
        // Validations
        if (!ValidationUtil.isNotEmpty(livre.getIsbn())) {
            throw new Exception("ISBN obligatoire");
        }
        if (!ValidationUtil.isValidISBN(livre.getIsbn())) {
            throw new Exception("ISBN invalide");
        }
        if (!ValidationUtil.isNotEmpty(livre.getTitre())) {
            throw new Exception("Titre obligatoire");
        }
        if (!ValidationUtil.isNotEmpty(livre.getAuteur())) {
            throw new Exception("Auteur obligatoire");
        }
        if (!ValidationUtil.isPositiveNumber(livre.getNombreExemplaires())) {
            throw new Exception("Nombre d'exemplaires doit être positif");
        }

        // Vérifier ISBN unique
        if (livreDAO.findByIsbn(livre.getIsbn()) != null) {
            throw new Exception("ISBN déjà existant");
        }

        livre.setExemplairesDisponibles(livre.getNombreExemplaires());
        livreDAO.save(livre);

        logService.log("AJOUT_LIVRE", "Livre ajouté: " + livre.getTitre());
    }

    public void modifierLivre(Livre livre) throws Exception {
        // Validations
        Livre existing = livreDAO.findById(livre.getId());
        if (existing == null) {
            throw new Exception("Livre introuvable");
        }

        if (!ValidationUtil.isNotEmpty(livre.getTitre())) {
            throw new Exception("Titre obligatoire");
        }
        if (!ValidationUtil.isNotEmpty(livre.getAuteur())) {
            throw new Exception("Auteur obligatoire");
        }

        // Ajuster exemplaires disponibles si nombre total change
        int diff = livre.getNombreExemplaires() - existing.getNombreExemplaires();
        livre.setExemplairesDisponibles(existing.getExemplairesDisponibles() + diff);

        if (livre.getExemplairesDisponibles() < 0) {
            throw new Exception("Nombre d'exemplaires insuffisant (emprunts en cours)");
        }

        livreDAO.update(livre);
        logService.log("MODIF_LIVRE", "Livre modifié: " + livre.getTitre());
    }

    public void supprimerLivre(int id) throws Exception {
        Livre livre = livreDAO.findById(id);
        if (livre == null) {
            throw new Exception("Livre introuvable");
        }

        // Vérifier s'il y a des emprunts actifs
        if (livreDAO.hasActiveEmprunts(id)) {
            throw new Exception("Impossible de supprimer: emprunts en cours");
        }

        livreDAO.delete(id);
        logService.log("SUPPRESSION_LIVRE", "Livre supprimé: " + livre.getTitre());
    }
}
