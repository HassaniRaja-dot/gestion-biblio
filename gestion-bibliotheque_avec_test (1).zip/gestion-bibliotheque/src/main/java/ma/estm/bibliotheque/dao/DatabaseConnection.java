package ma.estm.bibliotheque.dao;

import ma.estm.bibliotheque.util.PasswordUtil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/bibliotheque_db";
    private static final String USER = "root";
    private static final String PASSWORD = "rachid123";

    private static Connection connection = null;

    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("✓ Connexion à la base de données établie");
                initDatabase();
            } catch (ClassNotFoundException e) {
                throw new SQLException("Driver mysql introuvable", e);
            }
        }
        return connection;
    }

    private static void initDatabase() throws SQLException {
        try (Statement stmt = connection.createStatement()) {
            // Table Utilisateur
            stmt.execute(
                    "CREATE TABLE IF NOT EXISTS utilisateur (" +
                            "id INT AUTO_INCREMENT PRIMARY KEY, " +
                            "login VARCHAR(50) UNIQUE NOT NULL, " +
                            "mot_de_passe_hache VARCHAR(255) NOT NULL, " +
                            "role VARCHAR(20) NOT NULL, " +
                            "actif BOOLEAN DEFAULT TRUE, " +
                            "adherent_id INT)"
            );

            // Table Adherent
            stmt.execute(
                    "CREATE TABLE IF NOT EXISTS adherent (" +
                            "id INT AUTO_INCREMENT PRIMARY KEY, " +
                            "numero_adherent VARCHAR(50) UNIQUE NOT NULL, " +
                            "nom VARCHAR(100) NOT NULL, " +
                            "prenom VARCHAR(100) NOT NULL, " +
                            "email VARCHAR(100) UNIQUE NOT NULL, " +
                            "telephone VARCHAR(20), " +
                            "date_inscription DATE NOT NULL, " +
                            "bloque BOOLEAN DEFAULT FALSE)"
            );

            // Table Categorie
            stmt.execute(
                    "CREATE TABLE IF NOT EXISTS categorie (" +
                            "id INT AUTO_INCREMENT PRIMARY KEY, " +
                            "nom VARCHAR(100) UNIQUE NOT NULL, " +
                            "description VARCHAR(255))"
            );

            // Table Livre
            stmt.execute(
                    "CREATE TABLE IF NOT EXISTS livre (" +
                            "id INT AUTO_INCREMENT PRIMARY KEY, " +
                            "isbn VARCHAR(20) UNIQUE NOT NULL, " +
                            "titre VARCHAR(255) NOT NULL, " +
                            "auteur VARCHAR(100) NOT NULL, " +
                            "editeur VARCHAR(100), " +
                            "annee_publication INT, " +
                            "nombre_exemplaires INT NOT NULL, " +
                            "exemplaires_disponibles INT NOT NULL, " +
                            "categorie_id INT, " +
                            "FOREIGN KEY (categorie_id) REFERENCES categorie(id))"
            );

            // Table Emprunt
            stmt.execute(
                    "CREATE TABLE IF NOT EXISTS emprunt (" +
                            "id INT AUTO_INCREMENT PRIMARY KEY, " +
                            "adherent_id INT NOT NULL, " +
                            "livre_id INT NOT NULL, " +
                            "date_emprunt DATE NOT NULL, " +
                            "date_retour_prevue DATE NOT NULL, " +
                            "date_retour_effective DATE, " +
                            "statut VARCHAR(20) NOT NULL, " +
                            "FOREIGN KEY (adherent_id) REFERENCES adherent(id), " +
                            "FOREIGN KEY (livre_id) REFERENCES livre(id))"
            );

            // Table LogOperation
            stmt.execute(
                    "CREATE TABLE IF NOT EXISTS log_operation (" +
                            "id INT AUTO_INCREMENT PRIMARY KEY, " +
                            "date_operation TIMESTAMP NOT NULL, " +
                            "type_operation VARCHAR(50) NOT NULL, " +
                            "description VARCHAR(500), " +
                            "user_id INT NOT NULL, " +
                            "FOREIGN KEY (user_id) REFERENCES utilisateur(id))"
            );

            // Insertion de données initiales
            insertInitialData(stmt);

            System.out.println("✓ Base de données initialisée");
        }
    }

    private static void insertInitialData(Statement stmt) throws SQLException {
        // Vérifier si l'admin existe déjà
        var rs = stmt.executeQuery("SELECT COUNT(*) FROM utilisateur WHERE login='admin'");
        if (rs.next() && rs.getInt(1) == 0) {
            // Créer un compte admin par défaut
            String hashedPassword = PasswordUtil.hashPassword("admin123");
            stmt.execute(
                    "INSERT INTO utilisateur (login, mot_de_passe_hache, role, actif) " +
                            "VALUES ('admin', '" + hashedPassword + "', 'ADMIN', TRUE)"
            );
            System.out.println("✓ Compte admin créé (login: admin, password: admin123)");
        }

        // Vérifier si des catégories existent
        rs = stmt.executeQuery("SELECT COUNT(*) FROM categorie");
        if (rs.next() && rs.getInt(1) == 0) {
            stmt.execute("INSERT INTO categorie (nom, description) VALUES " +
                    "('Informatique', 'Livres sur l''informatique et la programmation'), " +
                    "('Mathématiques', 'Livres de mathématiques'), " +
                    "('Physique', 'Livres de physique'), " +
                    "('Littérature', 'Romans et œuvres littéraires'), " +
                    "('Histoire', 'Livres d''histoire')");
            System.out.println("✓ Catégories par défaut créées");
        }
    }

    public static void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("✓ Connexion fermée");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
