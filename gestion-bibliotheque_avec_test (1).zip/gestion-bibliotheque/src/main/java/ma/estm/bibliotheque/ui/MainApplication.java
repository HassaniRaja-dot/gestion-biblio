package ma.estm.bibliotheque.ui;

import ma.estm.bibliotheque.dao.DatabaseConnection;

import javax.swing.*;

public class MainApplication {
    public static void main(String[] args) {
        try {
            // Initialiser BD
            DatabaseConnection.getConnection();

            // Lancer interface
            SwingUtilities.invokeLater(() -> {
                LoginFrame loginFrame = new LoginFrame();
                loginFrame.setVisible(true);
            });

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                    "Erreur BD: " + e.getMessage(),
                    "Erreur",
                    JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}