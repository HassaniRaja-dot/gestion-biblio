package ma.estm.bibliotheque.ui.panels;



import ma.estm.bibliotheque.model.Adherent;
import ma.estm.bibliotheque.service.AdherentService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class AdherentPanel extends JPanel {
    private AdherentService adherentService;
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private JTextField numeroField;
    private JTextField nomField;
    private JTextField prenomField;
    private JTextField emailField;
    private JTextField telephoneField;
    private JCheckBox bloqueCheckBox;

    private Adherent adherentSelectionne;

    public AdherentPanel() {
        adherentService = new AdherentService();
        initComponents();
        loadAdherents();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Panel du haut - Titre et recherche
        JPanel topPanel = new JPanel(new BorderLayout());
        JLabel titleLabel = new JLabel("Gestion des Adhérents");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        topPanel.add(titleLabel, BorderLayout.NORTH);

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.add(new JLabel("Recherche:"));
        searchField = new JTextField(20);
        searchPanel.add(searchField);

        JButton searchButton = new JButton("Rechercher");
        searchButton.addActionListener(e -> searchAdherents());
        searchPanel.add(searchButton);

        JButton refreshButton = new JButton("Actualiser");
        refreshButton.addActionListener(e -> loadAdherents());
        searchPanel.add(refreshButton);

        topPanel.add(searchPanel, BorderLayout.CENTER);
        add(topPanel, BorderLayout.NORTH);

        // Panel du centre - Split entre tableau et formulaire
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);

        // Tableau des adhérents
        String[] columns = {"ID", "Numéro", "Nom", "Prénom", "Email", "Téléphone", "Bloqué"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                afficherAdherentSelectionne();
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        splitPane.setLeftComponent(scrollPane);

        // Formulaire
        JPanel formPanel = createFormPanel();
        splitPane.setRightComponent(formPanel);

        splitPane.setDividerLocation(500);
        add(splitPane, BorderLayout.CENTER);

        // Boutons du bas
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        JButton addButton = new JButton("Ajouter");
        addButton.addActionListener(e -> ajouterAdherent());
        buttonPanel.add(addButton);

        JButton updateButton = new JButton("Modifier");
        updateButton.addActionListener(e -> modifierAdherent());
        buttonPanel.add(updateButton);

        JButton deleteButton = new JButton("Supprimer");
        deleteButton.addActionListener(e -> supprimerAdherent());
        buttonPanel.add(deleteButton);

        JButton clearButton = new JButton("Nouveau");
        clearButton.addActionListener(e -> clearForm());
        buttonPanel.add(clearButton);

        add(buttonPanel, BorderLayout.SOUTH);
    }

    private JPanel createFormPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Détails de l'Adhérent"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);

        // Numéro Adhérent
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Numéro:"), gbc);

        numeroField = new JTextField(20);
        numeroField.setEnabled(false);
        gbc.gridx = 1;
        panel.add(numeroField, gbc);

        // Nom
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Nom:"), gbc);

        nomField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(nomField, gbc);

        // Prénom
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Prénom:"), gbc);

        prenomField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(prenomField, gbc);

        // Email
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("Email:"), gbc);

        emailField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(emailField, gbc);

        // Téléphone
        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(new JLabel("Téléphone:"), gbc);

        telephoneField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(telephoneField, gbc);

        // Bloqué
        gbc.gridx = 0;
        gbc.gridy = 5;
        panel.add(new JLabel("Bloqué:"), gbc);

        bloqueCheckBox = new JCheckBox();
        gbc.gridx = 1;
        panel.add(bloqueCheckBox, gbc);

        return panel;
    }

    private void loadAdherents() {
        tableModel.setRowCount(0);
        try {
            var adherents = adherentService.getAllAdherents();
            for (Adherent adherent : adherents) {
                tableModel.addRow(new Object[]{
                        adherent.getId(),
                        adherent.getNumeroAdherent(),
                        adherent.getNom(),
                        adherent.getPrenom(),
                        adherent.getEmail(),
                        adherent.getTelephone(),
                        adherent.isBloque() ? "Oui" : "Non"
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erreur lors du chargement: " + e.getMessage(),
                    "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void searchAdherents() {
        String keyword = searchField.getText().trim();
        tableModel.setRowCount(0);

        try {
            var adherents = adherentService.searchAdherents(keyword);
            for (Adherent adherent : adherents) {
                tableModel.addRow(new Object[]{
                        adherent.getId(),
                        adherent.getNumeroAdherent(),
                        adherent.getNom(),
                        adherent.getPrenom(),
                        adherent.getEmail(),
                        adherent.getTelephone(),
                        adherent.isBloque() ? "Oui" : "Non"
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erreur lors de la recherche: " + e.getMessage(),
                    "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void afficherAdherentSelectionne() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            return;
        }

        int adherentId = (int) tableModel.getValueAt(selectedRow, 0);
        adherentSelectionne = adherentService.getAllAdherents().stream()
                .filter(a -> a.getId() == adherentId)
                .findFirst()
                .orElse(null);

        if (adherentSelectionne != null) {
            numeroField.setText(adherentSelectionne.getNumeroAdherent());
            nomField.setText(adherentSelectionne.getNom());
            prenomField.setText(adherentSelectionne.getPrenom());
            emailField.setText(adherentSelectionne.getEmail());
            telephoneField.setText(adherentSelectionne.getTelephone());
            bloqueCheckBox.setSelected(adherentSelectionne.isBloque());
        }
    }

    private void ajouterAdherent() {
        try {
            Adherent adherent = new Adherent();
            adherent.setNom(nomField.getText().trim());
            adherent.setPrenom(prenomField.getText().trim());
            adherent.setEmail(emailField.getText().trim());
            adherent.setTelephone(telephoneField.getText().trim());

            adherentService.ajouterAdherent(adherent);

            JOptionPane.showMessageDialog(this,
                    "Adhérent ajouté avec succès!\nNuméro: " + adherent.getNumeroAdherent(),
                    "Succès", JOptionPane.INFORMATION_MESSAGE);

            clearForm();
            loadAdherents();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erreur: " + e.getMessage(),
                    "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void modifierAdherent() {
        if (adherentSelectionne == null) {
            JOptionPane.showMessageDialog(this,
                    "Veuillez sélectionner un adhérent à modifier",
                    "Information", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        try {
            adherentSelectionne.setNom(nomField.getText().trim());
            adherentSelectionne.setPrenom(prenomField.getText().trim());
            adherentSelectionne.setEmail(emailField.getText().trim());
            adherentSelectionne.setTelephone(telephoneField.getText().trim());
            adherentSelectionne.setBloque(bloqueCheckBox.isSelected());

            adherentService.modifierAdherent(adherentSelectionne);

            JOptionPane.showMessageDialog(this,
                    "Adhérent modifié avec succès",
                    "Succès", JOptionPane.INFORMATION_MESSAGE);

            clearForm();
            loadAdherents();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erreur: " + e.getMessage(),
                    "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void supprimerAdherent() {
        if (adherentSelectionne == null) {
            JOptionPane.showMessageDialog(this,
                    "Veuillez sélectionner un adhérent à supprimer",
                    "Information", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        int choice = JOptionPane.showConfirmDialog(this,
                "Êtes-vous sûr de vouloir supprimer cet adhérent?\n" +
                        adherentSelectionne.getNomComplet(),
                "Confirmation", JOptionPane.YES_NO_OPTION);

        if (choice == JOptionPane.YES_OPTION) {
            try {
                adherentService.supprimerAdherent(adherentSelectionne.getId());

                JOptionPane.showMessageDialog(this,
                        "Adhérent supprimé avec succès",
                        "Succès", JOptionPane.INFORMATION_MESSAGE);

                clearForm();
                loadAdherents();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                        "Erreur: " + e.getMessage(),
                        "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void clearForm() {
        adherentSelectionne = null;
        numeroField.setText("");
        nomField.setText("");
        prenomField.setText("");
        emailField.setText("");
        telephoneField.setText("");
        bloqueCheckBox.setSelected(false);
        table.clearSelection();
    }
}
