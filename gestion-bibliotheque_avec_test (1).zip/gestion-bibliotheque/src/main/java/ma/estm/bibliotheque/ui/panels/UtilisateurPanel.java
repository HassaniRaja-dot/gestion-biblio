package ma.estm.bibliotheque.ui.panels;

import ma.estm.bibliotheque.dao.AdherentDAO;
import ma.estm.bibliotheque.dao.UtilisateurDAO;
import ma.estm.bibliotheque.dao.impl.AdherentDAOImpl;
import ma.estm.bibliotheque.dao.impl.UtilisateurDAOImpl;
import ma.estm.bibliotheque.model.Adherent;
import ma.estm.bibliotheque.model.Role;
import ma.estm.bibliotheque.model.Utilisateur;
import ma.estm.bibliotheque.util.PasswordUtil;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class UtilisateurPanel extends JPanel {
    private UtilisateurDAO utilisateurDAO;
    private AdherentDAO adherentDAO;
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField searchField;

    public UtilisateurPanel() {
        utilisateurDAO = new UtilisateurDAOImpl();
        adherentDAO = new AdherentDAOImpl();
        initComponents();
        loadUtilisateurs();
    }

    private void initComponents() {
        setLayout(new BorderLayout(5, 5));

        // Top - Recherche
        JPanel topPanel = new JPanel();
        topPanel.add(new JLabel("Recherche:"));
        searchField = new JTextField(20);
        topPanel.add(searchField);

        JButton searchBtn = new JButton("Chercher");
        searchBtn.addActionListener(e -> searchUtilisateurs());
        topPanel.add(searchBtn);

        JButton refreshBtn = new JButton("Actualiser");
        refreshBtn.addActionListener(e -> loadUtilisateurs());
        topPanel.add(refreshBtn);

        add(topPanel, BorderLayout.NORTH);

        // Center - Table
        String[] columns = {"ID", "Login", "Rôle", "Actif", "Adhérent Lié"};
        tableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        add(new JScrollPane(table), BorderLayout.CENTER);

        // Bottom - Boutons
        JPanel btnPanel = new JPanel();

        JButton addBtn = new JButton("Créer Utilisateur");
        addBtn.addActionListener(e -> creerUtilisateur());
        btnPanel.add(addBtn);

        JButton editBtn = new JButton("Modifier");
        editBtn.addActionListener(e -> modifierUtilisateur());
        btnPanel.add(editBtn);

        JButton resetPwdBtn = new JButton("Réinitialiser MDP");
        resetPwdBtn.addActionListener(e -> reinitialiserMotDePasse());
        btnPanel.add(resetPwdBtn);

        JButton toggleBtn = new JButton("Activer/Désactiver");
        toggleBtn.addActionListener(e -> toggleActif());
        btnPanel.add(toggleBtn);

        JButton delBtn = new JButton("Supprimer");
        delBtn.addActionListener(e -> supprimerUtilisateur());
        btnPanel.add(delBtn);

        add(btnPanel, BorderLayout.SOUTH);
    }

    private void loadUtilisateurs() {
        tableModel.setRowCount(0);
        List<Utilisateur> users = utilisateurDAO.findAll();

        for (Utilisateur u : users) {
            String adherentInfo = "-";
            if (u.getAdherentId() != null) {
                Adherent a = adherentDAO.findById(u.getAdherentId());
                if (a != null) {
                    adherentInfo = a.getNomComplet();
                }
            }

            tableModel.addRow(new Object[]{
                    u.getId(),
                    u.getLogin(),
                    u.getRole(),
                    u.isActif() ? "Oui" : "Non",
                    adherentInfo
            });
        }
    }

    private void searchUtilisateurs() {
        String keyword = searchField.getText().trim().toLowerCase();
        if (keyword.isEmpty()) {
            loadUtilisateurs();
            return;
        }

        tableModel.setRowCount(0);
        List<Utilisateur> users = utilisateurDAO.findAll();

        for (Utilisateur u : users) {
            if (u.getLogin().toLowerCase().contains(keyword) ||
                    u.getRole().toString().toLowerCase().contains(keyword)) {

                String adherentInfo = "-";
                if (u.getAdherentId() != null) {
                    Adherent a = adherentDAO.findById(u.getAdherentId());
                    if (a != null) {
                        adherentInfo = a.getNomComplet();
                    }
                }

                tableModel.addRow(new Object[]{
                        u.getId(),
                        u.getLogin(),
                        u.getRole(),
                        u.isActif() ? "Oui" : "Non",
                        adherentInfo
                });
            }
        }
    }

    private void creerUtilisateur() {
        // Dialog pour le login
        String login = JOptionPane.showInputDialog(this, "Login:");
        if (login == null || login.trim().isEmpty()) return;

        // Vérifier si le login existe déjà
        if (utilisateurDAO.findByLogin(login) != null) {
            JOptionPane.showMessageDialog(this, "Ce login existe déjà!");
            return;
        }

        // Dialog pour le mot de passe
        JPasswordField pwd1 = new JPasswordField();
        JPasswordField pwd2 = new JPasswordField();
        Object[] message = {
                "Mot de passe:", pwd1,
                "Confirmer:", pwd2
        };

        int option = JOptionPane.showConfirmDialog(this, message,
                "Mot de passe", JOptionPane.OK_CANCEL_OPTION);

        if (option != JOptionPane.OK_OPTION) return;

        String password1 = new String(pwd1.getPassword());
        String password2 = new String(pwd2.getPassword());

        if (!password1.equals(password2)) {
            JOptionPane.showMessageDialog(this, "Les mots de passe ne correspondent pas!");
            return;
        }

        if (password1.length() < 4) {
            JOptionPane.showMessageDialog(this, "Mot de passe trop court (min 4 caractères)!");
            return;
        }

        // Dialog pour le rôle
        String[] roles = {"ADMIN", "USER"};
        String role = (String) JOptionPane.showInputDialog(this,
                "Rôle:", "Rôle", JOptionPane.QUESTION_MESSAGE,
                null, roles, roles[1]);

        if (role == null) return;

        // Si USER, demander l'adhérent lié
        Integer adherentId = null;
        if (role.equals("USER")) {
            List<Adherent> adherents = adherentDAO.findAll();

            if (adherents.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Aucun adhérent disponible. Créez d'abord un adhérent.");
                return;
            }

            String[] adherentNames = adherents.stream()
                    .map(a -> a.getId() + " - " + a.getNomComplet() + " (" + a.getEmail() + ")")
                    .toArray(String[]::new);

            String selected = (String) JOptionPane.showInputDialog(this,
                    "Lier à l'adhérent:", "Adhérent",
                    JOptionPane.QUESTION_MESSAGE, null, adherentNames, adherentNames[0]);

            if (selected == null) return;

            int index = java.util.Arrays.asList(adherentNames).indexOf(selected);
            adherentId = adherents.get(index).getId();
        }

        // Créer l'utilisateur
        try {
            Utilisateur user = new Utilisateur();
            user.setLogin(login.trim());
            user.setMotDePasseHache(PasswordUtil.hashPassword(password1));
            user.setRole(Role.valueOf(role));
            user.setActif(true);
            user.setAdherentId(adherentId);

            utilisateurDAO.save(user);

            JOptionPane.showMessageDialog(this,
                    "Utilisateur créé avec succès!\nLogin: " + login);

            loadUtilisateurs();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erreur: " + e.getMessage(),
                    "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void modifierUtilisateur() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Sélectionnez un utilisateur");
            return;
        }

        int userId = (int) tableModel.getValueAt(row, 0);
        Utilisateur user = utilisateurDAO.findById(userId);

        if (user == null) {
            JOptionPane.showMessageDialog(this, "Utilisateur introuvable");
            return;
        }

        // Modifier le login
        String newLogin = JOptionPane.showInputDialog(this,
                "Nouveau login:", user.getLogin());

        if (newLogin == null || newLogin.trim().isEmpty()) return;

        // Vérifier si le nouveau login existe déjà (sauf si c'est le même)
        if (!newLogin.equals(user.getLogin())) {
            Utilisateur existing = utilisateurDAO.findByLogin(newLogin);
            if (existing != null) {
                JOptionPane.showMessageDialog(this, "Ce login existe déjà!");
                return;
            }
        }

        // Modifier le rôle
        String[] roles = {"ADMIN", "USER"};
        String newRole = (String) JOptionPane.showInputDialog(this,
                "Rôle:", "Rôle", JOptionPane.QUESTION_MESSAGE,
                null, roles, user.getRole().toString());

        if (newRole == null) return;

        try {
            user.setLogin(newLogin.trim());
            user.setRole(Role.valueOf(newRole));

            utilisateurDAO.update(user);

            JOptionPane.showMessageDialog(this, "Utilisateur modifié avec succès!");
            loadUtilisateurs();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erreur: " + e.getMessage(),
                    "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void reinitialiserMotDePasse() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Sélectionnez un utilisateur");
            return;
        }

        int userId = (int) tableModel.getValueAt(row, 0);
        String login = (String) tableModel.getValueAt(row, 1);

        Utilisateur user = utilisateurDAO.findById(userId);
        if (user == null) return;

        // Demander nouveau mot de passe
        JPasswordField pwd1 = new JPasswordField();
        JPasswordField pwd2 = new JPasswordField();
        Object[] message = {
                "Nouveau mot de passe:", pwd1,
                "Confirmer:", pwd2
        };

        int option = JOptionPane.showConfirmDialog(this, message,
                "Réinitialiser MDP - " + login, JOptionPane.OK_CANCEL_OPTION);

        if (option != JOptionPane.OK_OPTION) return;

        String password1 = new String(pwd1.getPassword());
        String password2 = new String(pwd2.getPassword());

        if (!password1.equals(password2)) {
            JOptionPane.showMessageDialog(this, "Les mots de passe ne correspondent pas!");
            return;
        }

        if (password1.length() < 4) {
            JOptionPane.showMessageDialog(this, "Mot de passe trop court (min 4 caractères)!");
            return;
        }

        try {
            user.setMotDePasseHache(PasswordUtil.hashPassword(password1));
            utilisateurDAO.update(user);

            JOptionPane.showMessageDialog(this,
                    "Mot de passe réinitialisé avec succès!");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Erreur: " + e.getMessage(),
                    "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void toggleActif() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Sélectionnez un utilisateur");
            return;
        }

        int userId = (int) tableModel.getValueAt(row, 0);
        String login = (String) tableModel.getValueAt(row, 1);

        Utilisateur user = utilisateurDAO.findById(userId);
        if (user == null) return;

        String action = user.isActif() ? "désactiver" : "activer";
        int choice = JOptionPane.showConfirmDialog(this,
                "Voulez-vous " + action + " l'utilisateur " + login + "?",
                "Confirmation", JOptionPane.YES_NO_OPTION);

        if (choice == JOptionPane.YES_OPTION) {
            try {
                user.setActif(!user.isActif());
                utilisateurDAO.update(user);

                JOptionPane.showMessageDialog(this,
                        "Utilisateur " + (user.isActif() ? "activé" : "désactivé") + "!");

                loadUtilisateurs();

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                        "Erreur: " + e.getMessage(),
                        "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void supprimerUtilisateur() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Sélectionnez un utilisateur");
            return;
        }

        int userId = (int) tableModel.getValueAt(row, 0);
        String login = (String) tableModel.getValueAt(row, 1);

        // Empêcher de supprimer admin
        if (login.equals("admin")) {
            JOptionPane.showMessageDialog(this,
                    "Impossible de supprimer le compte admin!",
                    "Erreur", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int choice = JOptionPane.showConfirmDialog(this,
                "Supprimer l'utilisateur " + login + "?",
                "Confirmation", JOptionPane.YES_NO_OPTION);

        if (choice == JOptionPane.YES_OPTION) {
            try {
                utilisateurDAO.delete(userId);

                JOptionPane.showMessageDialog(this, "Utilisateur supprimé!");
                loadUtilisateurs();

            } catch (Exception e) {
                JOptionPane.showMessageDialog(this,
                        "Erreur: " + e.getMessage(),
                        "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}