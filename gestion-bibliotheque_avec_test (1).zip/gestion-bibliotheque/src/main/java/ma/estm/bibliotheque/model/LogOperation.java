package ma.estm.bibliotheque.model;

import java.util.Date;

public class LogOperation {
    private int id;
    private Date dateOperation;
    private String typeOperation;
    private String description;
    private int userId;
    private String userLogin;

    public LogOperation() {
        this.dateOperation = new Date();
    }

    public LogOperation(String typeOperation, String description, int userId) {
        this();
        this.typeOperation = typeOperation;
        this.description = description;
        this.userId = userId;
    }

    // Getters et Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Date getDateOperation() { return dateOperation; }
    public void setDateOperation(Date dateOperation) { this.dateOperation = dateOperation; }

    public String getTypeOperation() { return typeOperation; }
    public void setTypeOperation(String typeOperation) { this.typeOperation = typeOperation; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getUserLogin() { return userLogin; }
    public void setUserLogin(String userLogin) { this.userLogin = userLogin; }
}