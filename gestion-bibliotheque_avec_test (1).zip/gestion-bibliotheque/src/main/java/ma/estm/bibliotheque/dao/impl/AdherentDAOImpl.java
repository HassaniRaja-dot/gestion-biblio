package ma.estm.bibliotheque.dao.impl;

import ma.estm.bibliotheque.dao.AdherentDAO;
import ma.estm.bibliotheque.model.Adherent;
import ma.estm.bibliotheque.dao.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AdherentDAOImpl implements AdherentDAO {

    @Override
    public Adherent findById(int id) {
        String sql = "SELECT * FROM adherent WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return mapResultSetToAdherent(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public Adherent findByNumero(String numeroAdherent) {
        String sql = "SELECT * FROM adherent WHERE numero_adherent = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, numeroAdherent);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return mapResultSetToAdherent(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public Adherent findByEmail(String email) {
        String sql = "SELECT * FROM adherent WHERE email = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, email);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return mapResultSetToAdherent(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Adherent> findAll() {
        List<Adherent> adherents = new ArrayList<>();
        String sql = "SELECT * FROM adherent ORDER BY nom, prenom";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                adherents.add(mapResultSetToAdherent(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return adherents;
    }

    @Override
    public List<Adherent> search(String keyword) {
        List<Adherent> adherents = new ArrayList<>();
        String sql = "SELECT * FROM adherent WHERE " +
                "LOWER(nom) LIKE ? OR LOWER(prenom) LIKE ? OR " +
                "LOWER(email) LIKE ? OR numero_adherent LIKE ? " +
                "ORDER BY nom, prenom";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            String pattern = "%" + keyword.toLowerCase() + "%";
            stmt.setString(1, pattern);
            stmt.setString(2, pattern);
            stmt.setString(3, pattern);
            stmt.setString(4, pattern);

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                adherents.add(mapResultSetToAdherent(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return adherents;
    }

    @Override
    public void save(Adherent adherent) {
        String sql = "INSERT INTO adherent (numero_adherent, nom, prenom, email, " +
                "telephone, date_inscription, bloque) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, adherent.getNumeroAdherent());
            stmt.setString(2, adherent.getNom());
            stmt.setString(3, adherent.getPrenom());
            stmt.setString(4, adherent.getEmail());
            stmt.setString(5, adherent.getTelephone());
            stmt.setDate(6, new java.sql.Date(adherent.getDateInscription().getTime()));
            stmt.setBoolean(7, adherent.isBloque());

            stmt.executeUpdate();

            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                adherent.setId(rs.getInt(1));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void update(Adherent adherent) {
        String sql = "UPDATE adherent SET numero_adherent = ?, nom = ?, prenom = ?, " +
                "email = ?, telephone = ?, bloque = ? WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, adherent.getNumeroAdherent());
            stmt.setString(2, adherent.getNom());
            stmt.setString(3, adherent.getPrenom());
            stmt.setString(4, adherent.getEmail());
            stmt.setString(5, adherent.getTelephone());
            stmt.setBoolean(6, adherent.isBloque());
            stmt.setInt(7, adherent.getId());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(int id) {
        String sql = "DELETE FROM adherent WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int countEmpruntsActifs(int adherentId) {
        String sql = "SELECT COUNT(*) FROM emprunt WHERE adherent_id = ? " +
                "AND statut = 'EN_COURS'";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, adherentId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    private Adherent mapResultSetToAdherent(ResultSet rs) throws SQLException {
        Adherent adherent = new Adherent();
        adherent.setId(rs.getInt("id"));
        adherent.setNumeroAdherent(rs.getString("numero_adherent"));
        adherent.setNom(rs.getString("nom"));
        adherent.setPrenom(rs.getString("prenom"));
        adherent.setEmail(rs.getString("email"));
        adherent.setTelephone(rs.getString("telephone"));
        adherent.setDateInscription(rs.getDate("date_inscription"));
        adherent.setBloque(rs.getBoolean("bloque"));
        return adherent;
    }
}
