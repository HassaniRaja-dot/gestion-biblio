package util;

public class PasswordUtil {

    public static String hashPassword(String plain);

    public static boolean checkPassword(String plain, String hashed);
    

}
