public class DateUtil {

    public static LocalDate plus14Jours();

    public static boolean checkRetard(Emprunt e);
}
